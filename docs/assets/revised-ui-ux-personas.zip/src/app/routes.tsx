import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { WorkflowCanvas } from "./components/WorkflowCanvas";
import { BIDashboard } from "./components/BIDashboard";
import { HubMarketplace } from "./components/HubMarketplace";
import { ExecutionMonitor } from "./components/ExecutionMonitor";
import { Settings } from "./components/Settings";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: WorkflowCanvas },
      { path: "dashboard", Component: BIDashboard },
      { path: "hub", Component: HubMarketplace },
      { path: "monitor", Component: ExecutionMonitor },
      { path: "settings", Component: Settings },
    ],
  },
]);
