import { useState, useEffect } from "react";
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import {
  Cpu, Zap, Activity, Server, CheckCircle, AlertCircle,
  Clock, RefreshCw, MoreHorizontal, ChevronDown, TrendingUp,
  Database, Radio, Play, Square, Pause, Terminal,
  HardDrive, Network, Shield, GitBranch, X, ArrowUpRight,
  Layers,
} from "lucide-react";

// ── Mock Data ─────────────────────────────────────────────────────────────

function rand(min: number, max: number) { return min + Math.random() * (max - min); }

const generateGPUHistory = () =>
  Array.from({ length: 25 }, (_, i) => ({
    t: `${14}:${String(i * 2).padStart(2, "0")}`,
    a100_0: Math.round(rand(65, 92)),
    a100_1: Math.round(rand(50, 85)),
    rtx0: Math.round(rand(30, 70)),
    rtx1: Math.round(rand(25, 65)),
  }));

const generateMemHistory = () =>
  Array.from({ length: 25 }, (_, i) => ({
    t: `${14}:${String(i * 2).padStart(2, "0")}`,
    gpu_mem: Math.round(rand(55, 85)),
    cpu_mem: Math.round(rand(40, 65)),
    arrow_cache: Math.round(rand(15, 35)),
  }));

const GPU_HISTORY = generateGPUHistory();
const MEM_HISTORY = generateMemHistory();

const LATENCY_DATA = Array.from({ length: 20 }, (_, i) => ({
  t: `${14}:${String(i * 3).padStart(2, "0")}`,
  p50: Math.round(rand(28, 55)),
  p95: Math.round(rand(80, 140)),
  p99: Math.round(rand(150, 310)),
}));

const GPU_DEVICES = [
  { id: "cuda:0", name: "NVIDIA A100 80GB", vendor: "NVIDIA", compute: "8.0 (Ampere)", vram_total: 80, vram_used: 51.2, utilization: 78, temp: 72, power: 312, worker: "gpu-worker-0", status: "active" },
  { id: "cuda:1", name: "NVIDIA A100 80GB", vendor: "NVIDIA", compute: "8.0 (Ampere)", vram_total: 80, vram_used: 38.4, utilization: 61, temp: 68, power: 271, worker: "gpu-worker-1", status: "active" },
  { id: "cuda:2", name: "NVIDIA RTX 4090", vendor: "NVIDIA", compute: "8.9 (Ada Lovelace)", vram_total: 24, vram_used: 14.8, utilization: 45, temp: 64, power: 280, worker: "gpu-worker-2", status: "active" },
  { id: "cuda:3", name: "NVIDIA RTX 4090", vendor: "NVIDIA", compute: "8.9 (Ada Lovelace)", vram_total: 24, vram_used: 6.2, utilization: 18, temp: 52, power: 120, worker: "gpu-worker-3", status: "idle" },
];

const CPU_WORKERS = [
  { id: "cpu-0", cores: 32, usage: 64, mem_gb: 128, running_nodes: 8, status: "active" },
  { id: "cpu-1", cores: 32, usage: 47, mem_gb: 128, running_nodes: 5, status: "active" },
  { id: "cpu-2", cores: 16, usage: 82, mem_gb: 64, running_nodes: 11, status: "active" },
  { id: "cpu-3", cores: 16, usage: 12, mem_gb: 64, running_nodes: 1, status: "standby" },
];

const ACTIVE_WORKFLOWS = [
  { id: "wf-2401", name: "ML_Sensor_Pipeline_v3", mode: "batch", nodes: 13, completed: 8, status: "running", started: "14:21:08", user: "dr.chen@corp.com", gpu: "cuda:0,1", duration: "2m 34s", throughput: "—" },
  { id: "wf-2398", name: "IoT_Kafka_Ingest_Live", mode: "streaming", nodes: 5, completed: 5, status: "streaming", started: "13:55:12", user: "j.patel@corp.com", gpu: "—", duration: "27m 21s", throughput: "4,821 rec/s" },
  { id: "wf-2396", name: "FinancialML_CreditScore", mode: "batch", nodes: 22, completed: 22, status: "executed", started: "13:44:31", user: "m.okonkwo@corp.com", gpu: "cuda:2", duration: "18m 09s", throughput: "—" },
  { id: "wf-2394", name: "TextClassifier_NER_v2", mode: "batch", nodes: 9, completed: 4, status: "running", started: "14:18:55", user: "s.nakamura@corp.com", gpu: "cuda:2,3", duration: "4m 47s", throughput: "—" },
  { id: "wf-2392", name: "Hyperopt_Loop_RF", mode: "batch", nodes: 3, completed: 1, status: "running", started: "14:23:01", user: "dr.chen@corp.com", gpu: "—", duration: "0m 42s", throughput: "—" },
  { id: "wf-2389", name: "DICOM_Segmentation_Run4", mode: "batch", nodes: 17, completed: 17, status: "error", started: "13:30:44", user: "l.ibrahim@corp.com", gpu: "cuda:1", duration: "21m 18s", throughput: "—" },
];

const KAFKA_TOPICS = [
  { topic: "iot.sensors.raw", partitions: 12, offset: "18,432,941", lag: 0, throughput: "4,821 rec/s", consumers: 3 },
  { topic: "ml.predictions.out", partitions: 4, offset: "2,104,332", lag: 0, throughput: "1,203 rec/s", consumers: 2 },
  { topic: "analytics.events", partitions: 8, offset: "8,932,110", lag: 142, throughput: "2,840 rec/s", consumers: 4 },
  { topic: "juliaflow.bi.events", partitions: 2, offset: "134,211", lag: 0, throughput: "48 rec/s", consumers: 1 },
];

// ── Custom tooltip ─────────────────────────────────────────────────────────

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#1E2D42] border border-[#2A3F5C] rounded-lg p-2 text-xs shadow-xl">
      <p className="text-[#6B8AAE] mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full" style={{ background: p.color || p.stroke }} />
          <span className="text-[#E2EAF4]">{p.name}: <strong>{p.value}{typeof p.value === "number" && p.name.includes("%") ? "" : ""}</strong></span>
        </div>
      ))}
    </div>
  );
};

// ── GPU Card ──────────────────────────────────────────────────────────────

function GPUCard({ device }: { device: typeof GPU_DEVICES[0] }) {
  const utilColor = device.utilization > 75 ? "#EF4444" : device.utilization > 50 ? "#F59E0B" : "#10B981";
  const vramPct = (device.vram_used / device.vram_total) * 100;
  const vramColor = vramPct > 80 ? "#EF4444" : vramPct > 60 ? "#F59E0B" : "#10B981";

  return (
    <div className={`bg-[#162032] border rounded-xl p-4 flex flex-col gap-3 ${device.status === "idle" ? "border-[#2A3F5C] opacity-70" : "border-[#EAB30840]"}`}>
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-[#EAB30820] rounded-lg flex items-center justify-center">
            <Zap size={16} className="text-[#EAB308]" />
          </div>
          <div>
            <p className="text-xs text-[#E2EAF4]">{device.id}</p>
            <p className="text-[10px] text-[#4B6080]">{device.name}</p>
          </div>
        </div>
        <span className={`text-[10px] px-2 py-0.5 rounded-full ${device.status === "active" ? "bg-[#10B98120] text-[#10B981]" : "bg-[#1E2D42] text-[#4B6080]"}`}>
          {device.status}
        </span>
      </div>

      {/* Utilization */}
      <div>
        <div className="flex justify-between text-[10px] text-[#6B8AAE] mb-1">
          <span>GPU Utilization</span>
          <span style={{ color: utilColor }}>{device.utilization}%</span>
        </div>
        <div className="h-1.5 bg-[#1E2D42] rounded-full overflow-hidden">
          <div className="h-full rounded-full transition-all" style={{ width: `${device.utilization}%`, background: utilColor }} />
        </div>
      </div>

      {/* VRAM */}
      <div>
        <div className="flex justify-between text-[10px] text-[#6B8AAE] mb-1">
          <span>VRAM</span>
          <span style={{ color: vramColor }}>{device.vram_used.toFixed(1)} / {device.vram_total} GB</span>
        </div>
        <div className="h-1.5 bg-[#1E2D42] rounded-full overflow-hidden">
          <div className="h-full rounded-full transition-all" style={{ width: `${vramPct}%`, background: vramColor }} />
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2 pt-1 border-t border-[#1E2D42]">
        {[
          { label: "Temp", value: `${device.temp}°C`, color: device.temp > 80 ? "#EF4444" : "#6B8AAE" },
          { label: "Power", value: `${device.power}W`, color: "#6B8AAE" },
          { label: "SM", value: device.compute, color: "#6B8AAE" },
        ].map((s) => (
          <div key={s.label} className="text-center">
            <p className="text-[9px] text-[#4B6080]">{s.label}</p>
            <p className="text-[10px]" style={{ color: s.color }}>{s.value}</p>
          </div>
        ))}
      </div>

      <div className="flex items-center gap-1 text-[10px] text-[#4B6080]">
        <Server size={9} />{device.worker}
      </div>
    </div>
  );
}

// ── ExecutionMonitor ────────────────────────────────────────────────────────

export function ExecutionMonitor() {
  const [activeTab, setActiveTab] = useState<"workflows" | "gpu" | "kafka" | "logs">("workflows");
  const [gpuHistory] = useState(GPU_HISTORY);
  const [memHistory] = useState(MEM_HISTORY);
  const [refreshing, setRefreshing] = useState(false);

  const refresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  return (
    <div className="flex flex-col h-full bg-[#0F1826] overflow-hidden">
      {/* Toolbar */}
      <div className="flex items-center h-10 px-4 bg-[#0B1120] border-b border-[#1E2D42] gap-3 shrink-0">
        <span className="text-xs text-[#E2EAF4]">JuliaFlow Execution Monitor</span>
        <div className="w-px h-5 bg-[#1E2D42]" />
        <div className="flex items-center gap-1.5 text-[10px] text-[#10B981]">
          <div className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse" />
          JES Online · JBS Online · JSR Online
        </div>
        <div className="flex-1" />
        <button onClick={refresh}
          className="flex items-center gap-1.5 px-2.5 py-1 bg-[#162032] border border-[#2A3F5C] rounded text-xs text-[#E2EAF4] hover:bg-[#1E2D42] transition-colors">
          <RefreshCw size={11} className={refreshing ? "animate-spin" : ""} />Auto-refresh
        </button>
        <span className="text-[10px] text-[#4B6080]">Last: 5s ago</span>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-3 md:grid-cols-6 gap-3 p-3 bg-[#0B1120] border-b border-[#1E2D42] shrink-0">
        {[
          { label: "Active Workflows", value: "5", icon: <Activity size={14} />, color: "#3B82F6", sub: "3 batch · 1 stream · 1 loop" },
          { label: "GPU Workers", value: "4/4", icon: <Zap size={14} />, color: "#EAB308", sub: "3 active · 1 idle" },
          { label: "CPU Workers", value: "4/4", icon: <Cpu size={14} />, color: "#10B981", sub: "3 active · 1 standby" },
          { label: "Avg GPU Util", value: "50.5%", icon: <TrendingUp size={14} />, color: "#F97316", sub: "A100: 69.5% · RTX: 31.5%" },
          { label: "Arrow IPC Bus", value: "2.4 GB/s", icon: <Network size={14} />, color: "#06B6D4", sub: "Redis stream · MinIO" },
          { label: "Queue Depth", value: "12", icon: <Layers size={14} />, color: "#8B5CF6", sub: "8 GPU · 4 CPU jobs" },
        ].map((kpi) => (
          <div key={kpi.label} className="bg-[#162032] border border-[#2A3F5C] rounded-lg p-3 flex flex-col gap-1">
            <div className="flex items-center gap-1.5" style={{ color: kpi.color }}>
              {kpi.icon}
              <span className="text-[10px] text-[#6B8AAE]">{kpi.label}</span>
            </div>
            <p className="text-lg text-[#E2EAF4]" style={{ fontWeight: 600 }}>{kpi.value}</p>
            <p className="text-[9px] text-[#4B6080]">{kpi.sub}</p>
          </div>
        ))}
      </div>

      {/* Tab Bar */}
      <div className="flex items-center gap-1 px-4 pt-3 shrink-0 border-b border-[#1E2D42]">
        {(["workflows", "gpu", "kafka", "logs"] as const).map((tab) => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-xs capitalize rounded-t transition-colors
              ${activeTab === tab
                ? "bg-[#162032] text-[#3B82F6] border-t border-l border-r border-[#2A3F5C] border-b-[#162032]"
                : "text-[#4B6080] hover:text-[#E2EAF4]"}`}>
            {tab === "gpu" ? "GPU Cluster" : tab === "kafka" ? "Kafka / Streaming" : tab === "logs" ? "Execution Logs" : "Active Workflows"}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto bg-[#0F1826]">

        {/* Workflows Tab */}
        {activeTab === "workflows" && (
          <div className="p-4 space-y-4">
            <div className="bg-[#162032] border border-[#2A3F5C] rounded-xl overflow-hidden">
              <div className="flex items-center px-4 py-3 border-b border-[#1E2D42]">
                <span className="text-sm text-[#E2EAF4]">Active & Recent Executions</span>
                <div className="flex-1" />
                <span className="text-[10px] text-[#4B6080]">{ACTIVE_WORKFLOWS.length} workflows</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-[#1E2D42]">
                      {["Workflow", "Mode", "Progress", "Status", "GPU", "Duration", "Throughput", "User", ""].map((h) => (
                        <th key={h} className="text-left py-2 px-3 text-[10px] text-[#4B6080] whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {ACTIVE_WORKFLOWS.map((wf) => (
                      <tr key={wf.id} className="border-b border-[#1E2D42]/50 hover:bg-[#1E2D42]/50 transition-colors">
                        <td className="py-2.5 px-3">
                          <p className="text-[#E2EAF4] whitespace-nowrap">{wf.name}</p>
                          <p className="text-[9px] text-[#4B6080] font-mono">{wf.id}</p>
                        </td>
                        <td className="py-2.5 px-3">
                          <span className={`text-[10px] px-1.5 py-0.5 rounded
                            ${wf.mode === "streaming" ? "bg-[#06B6D420] text-[#06B6D4]" : "bg-[#3B82F620] text-[#3B82F6]"}`}>
                            {wf.mode}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          <div className="flex items-center gap-2">
                            <div className="w-24 h-1.5 bg-[#1E2D42] rounded-full overflow-hidden">
                              <div className="h-full bg-[#3B82F6] rounded-full" style={{ width: `${(wf.completed / wf.nodes) * 100}%` }} />
                            </div>
                            <span className="text-[10px] text-[#6B8AAE]">{wf.completed}/{wf.nodes}</span>
                          </div>
                        </td>
                        <td className="py-2.5 px-3">
                          <span className={`flex items-center gap-1 text-[10px] whitespace-nowrap
                            ${wf.status === "running" ? "text-[#3B82F6]" : wf.status === "streaming" ? "text-[#06B6D4]" : wf.status === "executed" ? "text-[#10B981]" : "text-[#EF4444]"}`}>
                            {wf.status === "running" && <div className="w-1.5 h-1.5 rounded-full bg-[#3B82F6] animate-pulse" />}
                            {wf.status === "streaming" && <div className="w-1.5 h-1.5 rounded-full bg-[#06B6D4] animate-pulse" />}
                            {wf.status === "executed" && <CheckCircle size={10} />}
                            {wf.status === "error" && <AlertCircle size={10} />}
                            {wf.status}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-[10px] text-[#EAB308] font-mono">{wf.gpu}</td>
                        <td className="py-2.5 px-3 text-[10px] text-[#6B8AAE] font-mono whitespace-nowrap">{wf.duration}</td>
                        <td className="py-2.5 px-3 text-[10px] text-[#06B6D4]">{wf.throughput}</td>
                        <td className="py-2.5 px-3 text-[10px] text-[#4B6080] whitespace-nowrap">{wf.user}</td>
                        <td className="py-2.5 px-3">
                          <button className="text-[#4B6080] hover:text-[#E2EAF4]"><MoreHorizontal size={13} /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Latency Chart */}
            <div className="bg-[#162032] border border-[#2A3F5C] rounded-xl p-4">
              <div className="flex items-center gap-2 mb-4">
                <Clock size={14} className="text-[#4B6080]" />
                <span className="text-sm text-[#E2EAF4]">Pipeline Latency Percentiles</span>
                <span className="text-[10px] text-[#4B6080]">Target p99 &lt;500ms</span>
              </div>
              <ResponsiveContainer width="100%" height={180}>
                <AreaChart data={LATENCY_DATA}>
                  <defs>
                    <linearGradient id="gradP99" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#EF4444" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="#EF4444" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1E2D42" />
                  <XAxis dataKey="t" tick={{ fill: "#4B6080", fontSize: 10 }} />
                  <YAxis tick={{ fill: "#4B6080", fontSize: 10 }} unit="ms" />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend wrapperStyle={{ fontSize: 10, color: "#6B8AAE" }} />
                  <Area type="monotone" dataKey="p99" name="p99 (ms)" stroke="#EF4444" fill="url(#gradP99)" strokeWidth={1.5} dot={false} />
                  <Line type="monotone" dataKey="p95" name="p95 (ms)" stroke="#F59E0B" strokeWidth={1.5} dot={false} />
                  <Line type="monotone" dataKey="p50" name="p50 (ms)" stroke="#10B981" strokeWidth={1.5} dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* GPU Tab */}
        {activeTab === "gpu" && (
          <div className="p-4 space-y-4">
            {/* GPU Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {GPU_DEVICES.map((device) => <GPUCard key={device.id} device={device} />)}
            </div>

            {/* GPU Utilization chart */}
            <div className="bg-[#162032] border border-[#2A3F5C] rounded-xl p-4">
              <div className="flex items-center gap-2 mb-4">
                <Zap size={14} className="text-[#EAB308]" />
                <span className="text-sm text-[#E2EAF4]">GPU Utilization History</span>
                <span className="text-[10px] text-[#4B6080]">NVML polling every 5s</span>
              </div>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={gpuHistory}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1E2D42" />
                  <XAxis dataKey="t" tick={{ fill: "#4B6080", fontSize: 10 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: "#4B6080", fontSize: 10 }} unit="%" />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend wrapperStyle={{ fontSize: 10, color: "#6B8AAE" }} />
                  <Line type="monotone" dataKey="a100_0" name="A100:0" stroke="#EAB308" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="a100_1" name="A100:1" stroke="#F97316" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="rtx0" name="RTX4090:0" stroke="#3B82F6" strokeWidth={1.5} dot={false} strokeDasharray="4 2" />
                  <Line type="monotone" dataKey="rtx1" name="RTX4090:1" stroke="#8B5CF6" strokeWidth={1.5} dot={false} strokeDasharray="4 2" />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Memory chart */}
            <div className="bg-[#162032] border border-[#2A3F5C] rounded-xl p-4">
              <div className="flex items-center gap-2 mb-4">
                <HardDrive size={14} className="text-[#3B82F6]" />
                <span className="text-sm text-[#E2EAF4]">Memory Utilization</span>
                <span className="text-[10px] text-[#4B6080]">GPU VRAM · System RAM · Arrow IPC Cache</span>
              </div>
              <ResponsiveContainer width="100%" height={180}>
                <AreaChart data={memHistory}>
                  <defs>
                    {[["gradGPU", "#EAB308"], ["gradCPU", "#3B82F6"], ["gradArrow", "#06B6D4"]].map(([id, color]) => (
                      <linearGradient key={id} id={id} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={color} stopOpacity={0.3} />
                        <stop offset="95%" stopColor={color} stopOpacity={0} />
                      </linearGradient>
                    ))}
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1E2D42" />
                  <XAxis dataKey="t" tick={{ fill: "#4B6080", fontSize: 10 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: "#4B6080", fontSize: 10 }} unit="%" />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend wrapperStyle={{ fontSize: 10, color: "#6B8AAE" }} />
                  <Area type="monotone" dataKey="gpu_mem" name="GPU VRAM %" stroke="#EAB308" fill="url(#gradGPU)" strokeWidth={1.5} dot={false} />
                  <Area type="monotone" dataKey="cpu_mem" name="System RAM %" stroke="#3B82F6" fill="url(#gradCPU)" strokeWidth={1.5} dot={false} />
                  <Area type="monotone" dataKey="arrow_cache" name="Arrow Cache %" stroke="#06B6D4" fill="url(#gradArrow)" strokeWidth={1.5} dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* CPU Workers */}
            <div className="bg-[#162032] border border-[#2A3F5C] rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <Cpu size={14} className="text-[#10B981]" />
                <span className="text-sm text-[#E2EAF4]">CPU Worker Pool</span>
              </div>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                {CPU_WORKERS.map((w) => (
                  <div key={w.id} className={`bg-[#1E2D42] border rounded-lg p-3 flex flex-col gap-2 ${w.status === "active" ? "border-[#2A3F5C]" : "border-[#2A3F5C] opacity-60"}`}>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[#E2EAF4]">{w.id}</span>
                      <span className={`text-[9px] px-1.5 py-0.5 rounded-full ${w.status === "active" ? "bg-[#10B98120] text-[#10B981]" : "bg-[#1E2D42] text-[#4B6080]"}`}>
                        {w.status}
                      </span>
                    </div>
                    <div>
                      <div className="flex justify-between text-[10px] text-[#4B6080] mb-1">
                        <span>CPU</span><span>{w.usage}%</span>
                      </div>
                      <div className="h-1.5 bg-[#162032] rounded-full overflow-hidden">
                        <div className="h-full rounded-full bg-[#10B981]" style={{ width: `${w.usage}%` }} />
                      </div>
                    </div>
                    <div className="flex justify-between text-[10px] text-[#4B6080]">
                      <span>{w.cores} cores · {w.mem_gb}GB</span>
                      <span className="text-[#3B82F6]">{w.running_nodes} nodes</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Kafka Tab */}
        {activeTab === "kafka" && (
          <div className="p-4 space-y-4">
            <div className="bg-[#162032] border border-[#2A3F5C] rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <Radio size={14} className="text-[#06B6D4]" />
                <span className="text-sm text-[#E2EAF4]">Kafka Topic Status (KRaft — 3 Brokers)</span>
                <div className="flex items-center gap-1.5 ml-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse" />
                  <span className="text-[10px] text-[#10B981]">Healthy</span>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-[#1E2D42]">
                      {["Topic", "Partitions", "Latest Offset", "Consumer Lag", "Throughput", "Consumers"].map((h) => (
                        <th key={h} className="text-left py-2 px-3 text-[10px] text-[#4B6080]">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {KAFKA_TOPICS.map((t) => (
                      <tr key={t.topic} className="border-b border-[#1E2D42]/50 hover:bg-[#1E2D42]/50 transition-colors">
                        <td className="py-2.5 px-3 font-mono text-[#06B6D4]">{t.topic}</td>
                        <td className="py-2.5 px-3 text-[#6B8AAE]">{t.partitions}</td>
                        <td className="py-2.5 px-3 font-mono text-[10px] text-[#6B8AAE]">{t.offset}</td>
                        <td className="py-2.5 px-3">
                          <span className={t.lag > 0 ? "text-[#F59E0B]" : "text-[#10B981]"}>
                            {t.lag > 0 ? `+${t.lag}` : "0 (current)"}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-[#E2EAF4]">{t.throughput}</td>
                        <td className="py-2.5 px-3 text-[#6B8AAE]">{t.consumers}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* JSR Streaming status */}
            <div className="bg-[#162032] border border-[#2A3F5C] rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <GitBranch size={14} className="text-[#8B5CF6]" />
                <span className="text-sm text-[#E2EAF4]">JuliaFlow Stream Runtime (JSR)</span>
              </div>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                {[
                  { label: "Active Streams", value: "1", color: "#06B6D4" },
                  { label: "Checkpoint Interval", value: "30s", color: "#8B5CF6" },
                  { label: "Last Checkpoint", value: "14:23:30", color: "#10B981" },
                  { label: "State Store", value: "PostgreSQL", color: "#3B82F6" },
                  { label: "Window Type", value: "Tumbling 1s", color: "#F97316" },
                  { label: "Backpressure", value: "None", color: "#10B981" },
                  { label: "Watermark Lag", value: "0ms", color: "#10B981" },
                  { label: "EOS Guarantee", value: "Exactly-Once", color: "#EAB308" },
                ].map((s) => (
                  <div key={s.label} className="bg-[#1E2D42] rounded-lg p-3 flex flex-col gap-1">
                    <p className="text-[10px] text-[#4B6080]">{s.label}</p>
                    <p className="text-sm" style={{ color: s.color, fontWeight: 600 }}>{s.value}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Logs Tab */}
        {activeTab === "logs" && (
          <div className="p-4">
            <div className="bg-[#0B1120] border border-[#1E2D42] rounded-xl overflow-hidden">
              <div className="flex items-center gap-2 px-4 py-2 border-b border-[#1E2D42]">
                <Terminal size={12} className="text-[#4B6080]" />
                <span className="text-xs text-[#6B8AAE]">OpenTelemetry Execution Trace — JuliaFlow Execution Service</span>
                <div className="flex-1" />
                <button className="text-[10px] text-[#4B6080] hover:text-[#E2EAF4] px-2 py-0.5 bg-[#162032] rounded">Filter</button>
              </div>
              <div className="p-3 font-mono space-y-0.5 max-h-96 overflow-y-auto">
                {[
                  { ts: "14:23:45.231", level: "INFO",  service: "JES",     msg: "WorkflowExecution[wf-2401] dispatching node n5 → GPU worker gpu-worker-0 (cuda:0)" },
                  { ts: "14:23:45.234", level: "INFO",  service: "JEP",     msg: "ComputeAffinity: n5 RandomForest → gpu_preferred → CUDA:0 available (VRAM free: 28.8GB)" },
                  { ts: "14:23:45.240", level: "INFO",  service: "Runner",  msg: "NodeRunner[n5]: deserializing Arrow IPC from Redis stream wf-2401:n4:output (847.3KB)" },
                  { ts: "14:23:45.241", level: "INFO",  service: "Runner",  msg: "NodeRunner[n5]: CUDA.@sync dispatching EvoTrees.fit!(model, X_train, y_train)" },
                  { ts: "14:23:45.890", level: "INFO",  service: "JSR",     msg: "StreamRuntime[wf-2398]: tumbling window 14:23:45 closed — 4,821 records — emitting aggregate" },
                  { ts: "14:23:45.891", level: "INFO",  service: "JBS",     msg: "BIService: WorkflowOutputReady event consumed — outlet sensor_live_feed — caching chart payload" },
                  { ts: "14:23:45.892", level: "INFO",  service: "JBS",     msg: "BIService: SSE push → 3 connected dashboard clients — latency 187ms" },
                  { ts: "14:23:45.901", level: "WARN",  service: "Runner",  msg: "NodeRunner[n10]: JSON malformed record (null sensor_id) — applying null-handling policy: skip" },
                  { ts: "14:23:46.110", level: "ERROR", service: "Runner",  msg: "NodeRunner[n12]: JDBC connection failed — host analytics.db:5432 — timeout after 5000ms" },
                  { ts: "14:23:46.111", level: "ERROR", service: "JES",     msg: "WorkflowExecution[wf-2401]: node n12 transitioned → ERROR — downstream n13 paused pending retry" },
                  { ts: "14:23:46.200", level: "INFO",  service: "JES",     msg: "Checkpoint[wf-2398]: snapshotting streaming state to PostgreSQL — node n9, n10, n11" },
                  { ts: "14:23:46.312", level: "INFO",  service: "NVML",    msg: "HardwareRegistry refresh: cuda:0 util=78% temp=72°C vram_free=28.8GB | cuda:1 util=61% temp=68°C" },
                  { ts: "14:23:46.401", level: "INFO",  service: "OTel",    msg: "Span exported: node_id=n5 node_type=RandomForest duration_ms=1168 device=CUDA:0 status=RUNNING" },
                ].map((entry, i) => (
                  <div key={i} className="flex items-start gap-2 text-[10px] py-0.5">
                    <span className="text-[#4B6080] shrink-0">{entry.ts}</span>
                    <span className={`shrink-0 w-10 ${entry.level === "ERROR" ? "text-[#EF4444]" : entry.level === "WARN" ? "text-[#F59E0B]" : "text-[#10B981]"}`}>
                      {entry.level}
                    </span>
                    <span className="text-[#8B5CF6] shrink-0 w-14">[{entry.service}]</span>
                    <span className={entry.level === "ERROR" ? "text-[#EF4444]/80" : entry.level === "WARN" ? "text-[#F59E0B]/80" : "text-[#6B8AAE]"}>
                      {entry.msg}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
