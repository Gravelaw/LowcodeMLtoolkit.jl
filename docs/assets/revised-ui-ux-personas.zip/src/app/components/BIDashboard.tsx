import { useState } from "react";
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line, ScatterChart, Scatter,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  RadialBarChart, RadialBar, PieChart, Pie, Cell,
} from "recharts";
import {
  Plus, Settings2, RefreshCw, Share2, Download, Eye,
  TrendingUp, TrendingDown, Minus, Zap, Activity, Database,
  Clock, Filter, ChevronDown, MoreHorizontal, Radio, Globe,
  BarChart2, Maximize2, X, Check, AlertCircle,
} from "lucide-react";

// ── Mock Data ─────────────────────────────────────────────────────────────

const streamData = Array.from({ length: 30 }, (_, i) => ({
  t: `${String(14).padStart(2,"0")}:${String(i * 2).padStart(2,"0")}`,
  throughput: 4200 + Math.sin(i * 0.4) * 800 + Math.random() * 300,
  latency: 38 + Math.cos(i * 0.3) * 12 + Math.random() * 8,
}));

const gpuData = Array.from({ length: 20 }, (_, i) => ({
  t: `${14}:${String(i * 3).padStart(2,"0")}`,
  a100_0: 72 + Math.sin(i * 0.5) * 18 + Math.random() * 5,
  a100_1: 65 + Math.cos(i * 0.4) * 20 + Math.random() * 5,
  cpu: 44 + Math.sin(i * 0.3) * 15 + Math.random() * 5,
}));

const workflowBarData = [
  { name: "ETL Batch", records: 2401, color: "#3B82F6" },
  { name: "ML Train", records: 1847, color: "#8B5CF6" },
  { name: "IoT Stream", records: 5820, color: "#06B6D4" },
  { name: "Reporting", records: 943, color: "#10B981" },
  { name: "Analytics", records: 3271, color: "#F97316" },
];

const modelScatter = Array.from({ length: 40 }, (_, i) => ({
  accuracy: 0.72 + Math.random() * 0.25,
  trainTime: 12 + Math.random() * 88,
  model: ["RandomForest", "GradientBoost", "SVM", "NeuralNet"][i % 4],
}));

const accuracyTrend = Array.from({ length: 10 }, (_, i) => ({
  epoch: i + 1,
  train: 0.6 + i * 0.03 + Math.random() * 0.01,
  val: 0.58 + i * 0.028 + Math.random() * 0.02,
}));

const pieData = [
  { name: "Batch", value: 38, fill: "#3B82F6" },
  { name: "Streaming", value: 31, fill: "#06B6D4" },
  { name: "ML Train", value: 19, fill: "#8B5CF6" },
  { name: "Reporting", value: 12, fill: "#10B981" },
];

// ── KPI Card ──────────────────────────────────────────────────────────────

interface KPIProps {
  label: string;
  value: string;
  change: string;
  changeDir: "up" | "down" | "flat";
  unit?: string;
  icon: React.ReactNode;
  color: string;
  live?: boolean;
}

function KPICard({ label, value, change, changeDir, unit, icon, color, live }: KPIProps) {
  return (
    <div className="bg-[#162032] border border-[#2A3F5C] rounded-xl p-4 flex flex-col gap-3 hover:border-[#3B82F6]/40 transition-colors">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: color + "22" }}>
            <span style={{ color }}>{icon}</span>
          </div>
          {live && (
            <div className="flex items-center gap-1 text-[10px] text-[#06B6D4]">
              <div className="w-1.5 h-1.5 rounded-full bg-[#06B6D4] animate-pulse" />
              LIVE
            </div>
          )}
        </div>
        <button className="text-[#4B6080] hover:text-[#E2EAF4]"><MoreHorizontal size={14} /></button>
      </div>
      <div>
        <div className="flex items-baseline gap-1">
          <span className="text-2xl text-[#E2EAF4]" style={{ fontWeight: 600 }}>{value}</span>
          {unit && <span className="text-xs text-[#4B6080]">{unit}</span>}
        </div>
        <p className="text-xs text-[#6B8AAE] mt-0.5">{label}</p>
      </div>
      <div className={`flex items-center gap-1 text-xs ${changeDir === "up" ? "text-[#10B981]" : changeDir === "down" ? "text-[#EF4444]" : "text-[#6B7280]"}`}>
        {changeDir === "up" ? <TrendingUp size={12} /> : changeDir === "down" ? <TrendingDown size={12} /> : <Minus size={12} />}
        {change} vs last execution
      </div>
    </div>
  );
}

// ── Chart Widget wrapper ───────────────────────────────────────────────────

function ChartWidget({ title, subtitle, live, children, className = "" }: {
  title: string; subtitle: string; live?: boolean; children: React.ReactNode; className?: string;
}) {
  return (
    <div className={`bg-[#162032] border border-[#2A3F5C] rounded-xl flex flex-col hover:border-[#3B82F6]/30 transition-colors ${className}`}>
      <div className="flex items-center gap-2 px-4 py-3 border-b border-[#1E2D42]">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className="text-sm text-[#E2EAF4]">{title}</p>
            {live && (
              <div className="flex items-center gap-1 text-[10px] text-[#06B6D4]">
                <div className="w-1.5 h-1.5 rounded-full bg-[#06B6D4] animate-pulse" />
                LIVE
              </div>
            )}
          </div>
          <p className="text-[10px] text-[#4B6080]">{subtitle}</p>
        </div>
        <button className="p-1 text-[#4B6080] hover:text-[#E2EAF4] hover:bg-[#1E2D42] rounded transition-colors">
          <Maximize2 size={13} />
        </button>
        <button className="p-1 text-[#4B6080] hover:text-[#E2EAF4] hover:bg-[#1E2D42] rounded transition-colors">
          <MoreHorizontal size={13} />
        </button>
      </div>
      <div className="flex-1 p-4 min-h-0">{children}</div>
    </div>
  );
}

// ── Custom tooltip ─────────────────────────────────────────────────────────

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#1E2D42] border border-[#2A3F5C] rounded-lg p-2 text-xs shadow-xl">
      <p className="text-[#6B8AAE] mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span className="text-[#E2EAF4]">{p.name}: <strong>{typeof p.value === "number" ? p.value.toFixed(1) : p.value}</strong></span>
        </div>
      ))}
    </div>
  );
};

// ── BIDashboard ────────────────────────────────────────────────────────────

export function BIDashboard() {
  const [editMode, setEditMode] = useState(false);
  const [timeRange, setTimeRange] = useState("Last 30 min");
  const [selectedOutlet, setSelectedOutlet] = useState("All Outlets");

  return (
    <div className="flex flex-col h-full bg-[#0F1826] overflow-hidden">
      {/* Dashboard Toolbar */}
      <div className="flex items-center h-10 px-4 bg-[#0B1120] border-b border-[#1E2D42] gap-3 shrink-0">
        <span className="text-xs text-[#E2EAF4]">IoT Sensor Analytics — Live Dashboard</span>
        <div className="w-px h-5 bg-[#1E2D42]" />
        <div className="flex items-center gap-1.5 px-2 py-1 bg-[#162032] border border-[#2A3F5C] rounded text-xs text-[#6B8AAE] cursor-pointer hover:border-[#3B82F6]/50 transition-colors">
          <Radio size={11} className="text-[#06B6D4]" />
          {selectedOutlet}
          <ChevronDown size={10} />
        </div>
        <div className="flex items-center gap-1.5 px-2 py-1 bg-[#162032] border border-[#2A3F5C] rounded text-xs text-[#6B8AAE] cursor-pointer hover:border-[#3B82F6]/50 transition-colors">
          <Clock size={11} />
          {timeRange}
          <ChevronDown size={10} />
        </div>
        <div className="flex-1" />
        <div className="flex items-center gap-1">
          <button onClick={() => setEditMode((v) => !v)}
            className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs transition-colors ${editMode ? "bg-[#3B82F6] text-white" : "bg-[#162032] border border-[#2A3F5C] text-[#E2EAF4] hover:bg-[#1E2D42]"}`}>
            <Settings2 size={11} />{editMode ? "Editing" : "Edit Layout"}
          </button>
          <button className="flex items-center gap-1.5 px-2.5 py-1 bg-[#162032] hover:bg-[#1E2D42] border border-[#2A3F5C] rounded text-[#E2EAF4] text-xs transition-colors">
            <Share2 size={11} />Share
          </button>
          <button className="flex items-center gap-1.5 px-2.5 py-1 bg-[#162032] hover:bg-[#1E2D42] border border-[#2A3F5C] rounded text-[#E2EAF4] text-xs transition-colors">
            <Download size={11} />Export
          </button>
        </div>
      </div>

      {/* Data Outlet binding bar */}
      <div className="flex items-center gap-2 px-4 py-2 bg-[#0F1826] border-b border-[#1E2D42] shrink-0 overflow-x-auto">
        <span className="text-[10px] text-[#4B6080] shrink-0">Data Outlets:</span>
        {[
          { name: "sensor_live_feed", color: "#06B6D4", active: true },
          { name: "ml_predictions", color: "#8B5CF6", active: true },
          { name: "batch_summary", color: "#3B82F6", active: false },
          { name: "gpu_metrics", color: "#EAB308", active: true },
          { name: "model_accuracy", color: "#10B981", active: true },
        ].map((outlet) => (
          <div key={outlet.name}
            className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full border text-[10px] shrink-0 cursor-pointer
              ${outlet.active ? "bg-opacity-10 border-opacity-60" : "opacity-40 border-[#2A3F5C]"}`}
            style={outlet.active ? { background: outlet.color + "18", borderColor: outlet.color + "60", color: outlet.color } : {}}>
            {outlet.active && <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: outlet.color }} />}
            {outlet.name}
            {outlet.active && <Check size={9} />}
          </div>
        ))}
        <button className="flex items-center gap-1 px-2 py-0.5 border border-dashed border-[#2A3F5C] rounded-full text-[10px] text-[#4B6080] hover:text-[#E2EAF4] hover:border-[#3B82F6]/50 transition-colors shrink-0">
          <Plus size={9} /> Add Outlet
        </button>
      </div>

      {/* Dashboard Grid */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* KPI Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPICard label="Records/Second (Live)" value="4,821" change="+12.4%" changeDir="up"
            icon={<Radio size={16} />} color="#06B6D4" live />
          <KPICard label="Active Workflows" value="47" change="+3" changeDir="up"
            icon={<Activity size={16} />} color="#3B82F6" />
          <KPICard label="GPU Utilization" value="78" unit="%" change="-2.1%" changeDir="down"
            icon={<Zap size={16} />} color="#EAB308" live />
          <KPICard label="p99 Latency" value="124" unit="ms" change="-18ms" changeDir="up"
            icon={<Clock size={16} />} color="#10B981" live />
        </div>

        {/* Second KPI row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPICard label="Model Accuracy (Best)" value="94.2" unit="%" change="+1.8%" changeDir="up"
            icon={<TrendingUp size={16} />} color="#8B5CF6" />
          <KPICard label="Records Processed Today" value="2.4M" change="+340K" changeDir="up"
            icon={<Database size={16} />} color="#F97316" />
          <KPICard label="Streaming Errors" value="3" change="-12" changeDir="up"
            icon={<AlertCircle size={16} />} color="#EF4444" />
          <KPICard label="Dashboard Update Lag" value="187" unit="ms" change="-42ms" changeDir="up"
            icon={<RefreshCw size={16} />} color="#10B981" live />
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <ChartWidget title="Streaming Throughput" subtitle="Records/sec — BI Outlet: sensor_live_feed" live className="col-span-2" style={{ minHeight: 220 }}>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={streamData}>
                <defs>
                  <linearGradient id="gradThroughput" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06B6D4" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#06B6D4" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gradLatency" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F97316" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#F97316" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E2D42" />
                <XAxis dataKey="t" tick={{ fill: "#4B6080", fontSize: 10 }} />
                <YAxis yAxisId="left" tick={{ fill: "#4B6080", fontSize: 10 }} />
                <YAxis yAxisId="right" orientation="right" tick={{ fill: "#4B6080", fontSize: 10 }} />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: 10, color: "#6B8AAE" }} />
                <Area yAxisId="left" type="monotone" dataKey="throughput" name="Throughput (rec/s)"
                  stroke="#06B6D4" fill="url(#gradThroughput)" strokeWidth={1.5} dot={false} />
                <Area yAxisId="right" type="monotone" dataKey="latency" name="Latency (ms)"
                  stroke="#F97316" fill="url(#gradLatency)" strokeWidth={1.5} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartWidget>

          <ChartWidget title="Execution by Type" subtitle="Records processed per workflow category">
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={workflowBarData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#1E2D42" horizontal={false} />
                <XAxis type="number" tick={{ fill: "#4B6080", fontSize: 10 }} />
                <YAxis dataKey="name" type="category" tick={{ fill: "#6B8AAE", fontSize: 10 }} width={70} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="records" name="Records (K)" radius={[0, 4, 4, 0]}>
                  {workflowBarData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} opacity={0.85} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartWidget>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <ChartWidget title="GPU Utilization Over Time" subtitle="NVIDIA A100 × 2 + CPU — BI Outlet: gpu_metrics" live className="col-span-2">
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={gpuData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E2D42" />
                <XAxis dataKey="t" tick={{ fill: "#4B6080", fontSize: 10 }} />
                <YAxis domain={[0, 100]} tick={{ fill: "#4B6080", fontSize: 10 }} unit="%" />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: 10, color: "#6B8AAE" }} />
                <Line type="monotone" dataKey="a100_0" name="A100:0" stroke="#EAB308" strokeWidth={1.5} dot={false} />
                <Line type="monotone" dataKey="a100_1" name="A100:1" stroke="#F97316" strokeWidth={1.5} dot={false} />
                <Line type="monotone" dataKey="cpu" name="CPU Avg" stroke="#6B7280" strokeWidth={1.5} dot={false} strokeDasharray="4 2" />
              </LineChart>
            </ResponsiveContainer>
          </ChartWidget>

          <ChartWidget title="Compute Distribution" subtitle="CPU vs GPU workload split">
            <div className="flex flex-col items-center gap-3">
              <ResponsiveContainer width="100%" height={140}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={40} outerRadius={65}
                    dataKey="value" paddingAngle={3}>
                    {pieData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
              <div className="grid grid-cols-2 gap-x-4 gap-y-1 w-full">
                {pieData.map((d) => (
                  <div key={d.name} className="flex items-center gap-1.5 text-[10px] text-[#6B8AAE]">
                    <div className="w-2 h-2 rounded-sm shrink-0" style={{ background: d.fill }} />
                    <span className="truncate">{d.name}</span>
                    <span className="ml-auto text-[#E2EAF4]">{d.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </ChartWidget>
        </div>

        {/* Charts Row 3 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <ChartWidget title="Model Training Accuracy" subtitle="Train vs Validation — BI Outlet: model_accuracy">
            <ResponsiveContainer width="100%" height={160}>
              <LineChart data={accuracyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E2D42" />
                <XAxis dataKey="epoch" tick={{ fill: "#4B6080", fontSize: 10 }} label={{ value: "Epoch", position: "insideBottom", offset: -2, fill: "#4B6080", fontSize: 10 }} />
                <YAxis domain={[0.5, 1]} tick={{ fill: "#4B6080", fontSize: 10 }} tickFormatter={(v) => `${(v * 100).toFixed(0)}%`} />
                <Tooltip content={<CustomTooltip />} formatter={(v: number) => `${(v * 100).toFixed(1)}%`} />
                <Legend wrapperStyle={{ fontSize: 10, color: "#6B8AAE" }} />
                <Line type="monotone" dataKey="train" name="Train Acc" stroke="#8B5CF6" strokeWidth={2} dot={{ r: 3, fill: "#8B5CF6" }} />
                <Line type="monotone" dataKey="val" name="Val Acc" stroke="#10B981" strokeWidth={2} dot={{ r: 3, fill: "#10B981" }} strokeDasharray="4 2" />
              </LineChart>
            </ResponsiveContainer>
          </ChartWidget>

          <ChartWidget title="Model Performance Scatter" subtitle="Accuracy vs Training Time — BI Outlet: ml_predictions">
            <ResponsiveContainer width="100%" height={160}>
              <ScatterChart>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E2D42" />
                <XAxis dataKey="trainTime" name="Train Time (s)" tick={{ fill: "#4B6080", fontSize: 10 }} unit="s" />
                <YAxis dataKey="accuracy" name="Accuracy" tick={{ fill: "#4B6080", fontSize: 10 }}
                  domain={[0.7, 1]} tickFormatter={(v) => `${(v * 100).toFixed(0)}%`} />
                <Tooltip cursor={{ strokeDasharray: "3 3" }} content={<CustomTooltip />}
                  formatter={(v: number, n: string) => n === "Accuracy" ? `${(v * 100).toFixed(1)}%` : `${v.toFixed(0)}s`} />
                <Scatter name="Models" data={modelScatter} fill="#3B82F6" opacity={0.7} />
              </ScatterChart>
            </ResponsiveContainer>
          </ChartWidget>
        </div>

        {/* Semantic Layer / Outlet Table */}
        <div className="bg-[#162032] border border-[#2A3F5C] rounded-xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <Database size={14} className="text-[#3B82F6]" />
            <span className="text-sm text-[#E2EAF4]">JuliaFlow Semantic Layer (JSL) — Measures & Calculated Columns</span>
            <div className="flex-1" />
            <button className="flex items-center gap-1 text-[10px] text-[#4B6080] hover:text-[#E2EAF4] transition-colors">
              <Plus size={10} />Add Measure
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#1E2D42]">
                  {["Measure Name", "Formula", "Outlet", "Type", "Cached"].map((h) => (
                    <th key={h} className="text-left py-2 px-3 text-[10px] text-[#4B6080]">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[
                  { name: "Total Records", formula: "SUM(sensor_live_feed.record_count)", outlet: "sensor_live_feed", type: "Measure", cached: true },
                  { name: "Avg Sensor Value", formula: "AVG(sensor_live_feed.sensor_val)", outlet: "sensor_live_feed", type: "Measure", cached: true },
                  { name: "Anomaly Rate", formula: "COUNTD(anomaly_flag=true) / COUNT(*)", outlet: "ml_predictions", type: "Calculated", cached: false },
                  { name: "GPU Efficiency", formula: "AVG(gpu_metrics.utilisation_pct) / 100", outlet: "gpu_metrics", type: "Measure", cached: true },
                  { name: "Model Win Rate", formula: "SUM(model_accuracy.is_best) / COUNT(*)", outlet: "model_accuracy", type: "Calculated", cached: false },
                ].map((row) => (
                  <tr key={row.name} className="border-b border-[#1E2D42]/50 hover:bg-[#1E2D42]/50 transition-colors">
                    <td className="py-2 px-3 text-[#E2EAF4]">{row.name}</td>
                    <td className="py-2 px-3 font-mono text-[#8B5CF6] text-[10px]">{row.formula}</td>
                    <td className="py-2 px-3">
                      <span className="px-1.5 py-0.5 rounded-full text-[9px]" style={{ background: "#06B6D422", color: "#06B6D4" }}>
                        {row.outlet}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-[#6B8AAE]">{row.type}</td>
                    <td className="py-2 px-3">
                      {row.cached
                        ? <span className="text-[#10B981] flex items-center gap-1"><Check size={10} /> Cached</span>
                        : <span className="text-[#4B6080]">—</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
