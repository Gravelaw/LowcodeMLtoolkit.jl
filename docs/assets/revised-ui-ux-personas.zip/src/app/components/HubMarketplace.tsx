import { useState } from "react";
import {
  Search, Star, Download, Package, Shield, CheckCircle, Globe,
  Filter, ChevronDown, Plus, ArrowUpRight, Clock, Tag,
  Zap, Brain, Database, Radio, BarChart2, GitBranch, FlaskConical,
  Microscope, DollarSign, Code, Map, TrendingUp, Bot, Factory,
  RefreshCw, Upload, X,
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────

type Tier = "official" | "verified" | "community" | "enterprise";

interface Extension {
  id: string;
  name: string;
  description: string;
  author: string;
  tier: Tier;
  downloads: string;
  stars: number;
  version: string;
  lastUpdated: string;
  tags: string[];
  compatible: string;
  gpuRequired?: boolean;
  icon: React.ReactNode;
  iconBg: string;
}

// ── Tier Config ────────────────────────────────────────────────────────────

const TIER_CONFIG: Record<Tier, { label: string; color: string; bg: string; icon: React.ReactNode; desc: string }> = {
  official: {
    label: "Official",
    color: "#3B82F6",
    bg: "#3B82F622",
    icon: <Shield size={10} />,
    desc: "Maintained by JuliaFlow core team",
  },
  verified: {
    label: "Verified",
    color: "#10B981",
    bg: "#10B98122",
    icon: <CheckCircle size={10} />,
    desc: "Reviewed by JuliaFlow team",
  },
  community: {
    label: "Community",
    color: "#F97316",
    bg: "#F9731622",
    icon: <Globe size={10} />,
    desc: "Self-published, experimental",
  },
  enterprise: {
    label: "Enterprise",
    color: "#8B5CF6",
    bg: "#8B5CF622",
    icon: <Package size={10} />,
    desc: "Organisation-scoped",
  },
};

// ── Mock Extensions ────────────────────────────────────────────────────────

const EXTENSIONS: Extension[] = [
  { id: "e1", name: "JuliaFlow Base", description: "300+ core transformation, I/O, ML, statistics, and visualisation nodes. The complete JuliaFlow analytics foundation.", author: "JuliaFlow Core", tier: "official", downloads: "28.4K", stars: 4.9, version: "1.0.2", lastUpdated: "2 days ago", tags: ["IO", "Transform", "ML", "Stats", "Viz"], compatible: "1.0+", icon: <Package size={18} />, iconBg: "#3B82F6" },
  { id: "e2", name: "JuliaFlow Deep Learning", description: "Flux.jl-based CNN, RNN, Transformer, GAN node library. Full GPU acceleration via CUDA.jl and AMDGPU.jl backends.", author: "JuliaFlow Core", tier: "official", downloads: "14.2K", stars: 4.8, version: "1.0.1", lastUpdated: "5 days ago", tags: ["Deep Learning", "GPU", "Flux.jl", "Transformer"], compatible: "1.0+", gpuRequired: true, icon: <Brain size={18} />, iconBg: "#8B5CF6" },
  { id: "e3", name: "JuliaFlow Geospatial", description: "Choropleth maps, spatial joins, shapefile I/O, coordinate transforms via ArchGDAL.jl and GeoInterface.jl.", author: "JuliaFlow Core", tier: "official", downloads: "8.7K", stars: 4.7, version: "1.0.0", lastUpdated: "1 week ago", tags: ["Geospatial", "Maps", "GIS", "ArchGDAL"], compatible: "1.0+", icon: <Map size={18} />, iconBg: "#10B981" },
  { id: "e4", name: "JuliaFlow Text Processing", description: "Tokenisation, TF-IDF, word vectors, NER, sentiment analysis. GPU-accelerated inference via Transformers.jl.", author: "JuliaFlow Core", tier: "official", downloads: "11.3K", stars: 4.8, version: "1.0.1", lastUpdated: "3 days ago", tags: ["NLP", "Text", "Transformers", "GPU"], compatible: "1.0+", gpuRequired: true, icon: <Code size={18} />, iconBg: "#06B6D4" },
  { id: "e5", name: "JuliaFlow Time Series", description: "ARIMA, Prophet, STL decomposition, anomaly detection, and temporal feature engineering nodes.", author: "JuliaFlow Core", tier: "official", downloads: "9.1K", stars: 4.7, version: "1.0.0", lastUpdated: "1 week ago", tags: ["Time Series", "ARIMA", "Forecasting", "Anomaly"], compatible: "1.0+", icon: <TrendingUp size={18} />, iconBg: "#F97316" },
  { id: "e6", name: "JuliaFlow Database+", description: "Extended connectors for Snowflake, BigQuery, Databricks, ClickHouse, and Elasticsearch.", author: "JuliaFlow Core", tier: "official", downloads: "6.4K", stars: 4.6, version: "1.0.0", lastUpdated: "2 weeks ago", tags: ["Database", "Snowflake", "BigQuery", "JDBC"], compatible: "1.0+", icon: <Database size={18} />, iconBg: "#3B82F6" },
  { id: "e7", name: "JuliaFlow AutoML", description: "Automated feature selection, algorithm selection, and ensemble building via AutoMLPipeline.jl integration.", author: "JuliaFlow Core", tier: "official", downloads: "7.2K", stars: 4.7, version: "1.0.0", lastUpdated: "1 week ago", tags: ["AutoML", "Ensemble", "Feature Selection"], compatible: "1.0+", icon: <Zap size={18} />, iconBg: "#EAB308" },
  { id: "e8", name: "JuliaFlow Industrial IoT", description: "OPC-UA reader, MQTT subscriber, PLC data acquisition and Modbus protocol nodes for industrial deployments.", author: "IndustrialSoft GmbH", tier: "verified", downloads: "3.2K", stars: 4.5, version: "0.8.2", lastUpdated: "2 weeks ago", tags: ["IoT", "OPC-UA", "MQTT", "Modbus", "PLC"], compatible: "1.0+", icon: <Factory size={18} />, iconBg: "#F97316" },
  { id: "e9", name: "JuliaFlow FinancialML", description: "Factor models, options pricing (Black-Scholes, Heston), credit risk scoring, and market regime detection.", author: "QuantFlow Labs", tier: "verified", downloads: "4.8K", stars: 4.6, version: "0.9.1", lastUpdated: "10 days ago", tags: ["Finance", "Options", "Risk", "Factor Models"], compatible: "1.0+", icon: <DollarSign size={18} />, iconBg: "#10B981" },
  { id: "e10", name: "JuliaFlow Medical Imaging", description: "DICOM processing, segmentation, radiomics feature extraction via DICOMUtils.jl. HIPAA-ready workflows.", author: "MedAnalytics Inc", tier: "verified", downloads: "2.1K", stars: 4.5, version: "0.7.3", lastUpdated: "3 weeks ago", tags: ["DICOM", "Imaging", "Radiomics", "HIPAA"], compatible: "1.0+", icon: <Microscope size={18} />, iconBg: "#EC4899" },
  { id: "e11", name: "JuliaFlow LLM Suite", description: "LLM prompt engineering nodes, vector embeddings, RAG pipeline builder, and local model inference via Ollama.jl.", author: "AIStack Community", tier: "community", downloads: "5.9K", stars: 4.3, version: "0.4.2", lastUpdated: "4 days ago", tags: ["LLM", "RAG", "Embeddings", "Ollama", "OpenAI"], compatible: "1.0+", gpuRequired: true, icon: <Bot size={18} />, iconBg: "#8B5CF6" },
  { id: "e12", name: "JuliaFlow Cheminformatics", description: "Molecular structure processing with RDKit.jl wrapper. GPU-accelerated molecular fingerprints and similarity search.", author: "ChemFlow Team", tier: "community", downloads: "1.4K", stars: 4.1, version: "0.3.0", lastUpdated: "1 month ago", tags: ["Chemistry", "RDKit", "Molecules", "Fingerprints"], compatible: "1.0+", icon: <FlaskConical size={18} />, iconBg: "#10B981" },
  { id: "e13", name: "JuliaFlow Salesforce", description: "SOQL query node, Salesforce object CRUD, Marketing Cloud connector, and Einstein Analytics integration.", author: "Apex Analytics", tier: "verified", downloads: "2.8K", stars: 4.4, version: "0.6.1", lastUpdated: "2 weeks ago", tags: ["Salesforce", "CRM", "SOQL", "Marketing"], compatible: "1.0+", icon: <Globe size={18} />, iconBg: "#3B82F6" },
  { id: "e14", name: "JuliaFlow ScikitLearn Bridge", description: "Direct interop with Python scikit-learn via PythonCall.jl for full ecosystem access with zero-copy data transfer.", author: "PyJulia Community", tier: "community", downloads: "3.7K", stars: 4.2, version: "0.5.0", lastUpdated: "3 weeks ago", tags: ["Python", "scikit-learn", "Bridge", "PythonCall"], compatible: "1.0+", icon: <GitBranch size={18} />, iconBg: "#F97316" },
  { id: "e15", name: "Enterprise Audit Pack", description: "Organisation-scoped compliance nodes: audit logging, PII masking, data lineage, GDPR/HIPAA report generation.", author: "AcmeCorp (Private)", tier: "enterprise", downloads: "—", stars: 5.0, version: "2.1.0", lastUpdated: "1 week ago", tags: ["Audit", "GDPR", "HIPAA", "PII", "Compliance"], compatible: "1.0+", icon: <Shield size={18} />, iconBg: "#6B7280" },
];

// ── Filters ────────────────────────────────────────────────────────────────

const CATEGORIES = ["All", "Machine Learning", "Data I/O", "Transform", "Visualisation", "Streaming", "NLP/Text", "Finance", "Science", "IoT"];

// ── Extension Card ─────────────────────────────────────────────────────────

function ExtCard({ ext, onInstall }: { ext: Extension; onInstall: (id: string) => void }) {
  const [installed, setInstalled] = useState(false);
  const tier = TIER_CONFIG[ext.tier];

  return (
    <div className="bg-[#162032] border border-[#2A3F5C] rounded-xl p-4 flex flex-col gap-3 hover:border-[#3B82F6]/50 hover:shadow-lg hover:shadow-[#3B82F6]/5 transition-all cursor-pointer">
      {/* Header */}
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
          style={{ background: ext.iconBg + "33", color: ext.iconBg }}>
          {ext.icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm text-[#E2EAF4]">{ext.name}</span>
            {ext.gpuRequired && (
              <span className="flex items-center gap-0.5 text-[9px] text-[#EAB308] bg-[#EAB30820] border border-[#EAB30840] rounded px-1 py-0.5">
                <Zap size={8} />GPU
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="flex items-center gap-1 text-[10px] rounded-full px-1.5 py-0.5"
              style={{ background: tier.bg, color: tier.color }}>
              {tier.icon}{tier.label}
            </span>
            <span className="text-[10px] text-[#4B6080]">by {ext.author}</span>
          </div>
        </div>
      </div>

      {/* Description */}
      <p className="text-[11px] text-[#6B8AAE] leading-relaxed line-clamp-2">{ext.description}</p>

      {/* Tags */}
      <div className="flex flex-wrap gap-1">
        {ext.tags.slice(0, 4).map((tag) => (
          <span key={tag} className="px-1.5 py-0.5 bg-[#1E2D42] border border-[#2A3F5C] rounded text-[9px] text-[#4B6080]">
            {tag}
          </span>
        ))}
        {ext.tags.length > 4 && (
          <span className="px-1.5 py-0.5 text-[9px] text-[#4B6080]">+{ext.tags.length - 4}</span>
        )}
      </div>

      {/* Footer */}
      <div className="flex items-center gap-3 pt-1 border-t border-[#1E2D42]">
        <div className="flex items-center gap-1 text-[10px] text-[#4B6080]">
          <Star size={10} className="text-[#EAB308]" />
          <span className="text-[#E2EAF4]">{ext.stars.toFixed(1)}</span>
        </div>
        <div className="flex items-center gap-1 text-[10px] text-[#4B6080]">
          <Download size={10} />
          {ext.downloads}
        </div>
        <div className="flex items-center gap-1 text-[10px] text-[#4B6080]">
          <Tag size={10} />
          v{ext.version}
        </div>
        <div className="flex items-center gap-1 text-[10px] text-[#4B6080]">
          <Clock size={10} />
          {ext.lastUpdated}
        </div>
        <div className="flex-1" />
        <button
          onClick={(e) => { e.stopPropagation(); setInstalled(!installed); onInstall(ext.id); }}
          className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs transition-all
            ${installed
              ? "bg-[#10B98120] border border-[#10B98140] text-[#10B981]"
              : "bg-[#3B82F6] hover:bg-[#2563EB] text-white"}`}>
          {installed ? <><CheckCircle size={10} />Installed</> : <><Download size={10} />Install</>}
        </button>
      </div>
    </div>
  );
}

// ── HubMarketplace ─────────────────────────────────────────────────────────

export function HubMarketplace() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [activeTier, setActiveTier] = useState<Tier | "all">("all");
  const [sortBy, setSortBy] = useState("Downloads");
  const [publishOpen, setPublishOpen] = useState(false);
  const [installed, setInstalled] = useState<Set<string>>(new Set());

  const filtered = EXTENSIONS.filter((ext) => {
    const matchSearch = ext.name.toLowerCase().includes(search.toLowerCase()) ||
      ext.description.toLowerCase().includes(search.toLowerCase()) ||
      ext.tags.some((t) => t.toLowerCase().includes(search.toLowerCase()));
    const matchTier = activeTier === "all" || ext.tier === activeTier;
    const matchCat = activeCategory === "All" || ext.tags.some((t) =>
      t.toLowerCase().includes(activeCategory.toLowerCase().split("/")[0]));
    return matchSearch && matchTier && matchCat;
  });

  return (
    <div className="flex h-full bg-[#0F1826] overflow-hidden">
      {/* Sidebar */}
      <div className="w-52 shrink-0 flex flex-col bg-[#0B1120] border-r border-[#1E2D42] overflow-hidden">
        <div className="p-3 border-b border-[#1E2D42]">
          <p className="text-[11px] text-[#6B8AAE] mb-2">Filter by Tier</p>
          <div className="space-y-1">
            <button onClick={() => setActiveTier("all")}
              className={`flex items-center gap-2 w-full px-2 py-1.5 rounded text-xs transition-colors
                ${activeTier === "all" ? "bg-[#1E2D42] text-[#E2EAF4]" : "text-[#4B6080] hover:bg-[#162032] hover:text-[#E2EAF4]"}`}>
              <Globe size={11} />All Tiers
              <span className="ml-auto text-[10px]">{EXTENSIONS.length}</span>
            </button>
            {(Object.entries(TIER_CONFIG) as [Tier, typeof TIER_CONFIG[Tier]][]).map(([tier, config]) => (
              <button key={tier} onClick={() => setActiveTier(tier)}
                className={`flex items-center gap-2 w-full px-2 py-1.5 rounded text-xs transition-colors
                  ${activeTier === tier ? "bg-[#1E2D42] text-[#E2EAF4]" : "text-[#4B6080] hover:bg-[#162032] hover:text-[#E2EAF4]"}`}>
                <span style={{ color: config.color }}>{config.icon}</span>
                {config.label}
                <span className="ml-auto text-[10px]">{EXTENSIONS.filter((e) => e.tier === tier).length}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="p-3 border-b border-[#1E2D42]">
          <p className="text-[11px] text-[#6B8AAE] mb-2">Category</p>
          <div className="space-y-0.5">
            {CATEGORIES.map((cat) => (
              <button key={cat} onClick={() => setActiveCategory(cat)}
                className={`w-full text-left px-2 py-1 rounded text-xs transition-colors
                  ${activeCategory === cat ? "bg-[#1E2D42] text-[#E2EAF4]" : "text-[#4B6080] hover:bg-[#162032] hover:text-[#E2EAF4]"}`}>
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="p-3">
          <p className="text-[11px] text-[#6B8AAE] mb-2">Platform Stats</p>
          <div className="space-y-2">
            {[
              { label: "Total Extensions", value: "127" },
              { label: "Official (Tier 1)", value: "38" },
              { label: "Verified (Tier 2)", value: "54" },
              { label: "Community (Tier 3)", value: "35" },
            ].map((s) => (
              <div key={s.label} className="flex justify-between text-[10px]">
                <span className="text-[#4B6080]">{s.label}</span>
                <span className="text-[#E2EAF4]">{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center gap-3 px-4 py-2 bg-[#0B1120] border-b border-[#1E2D42] shrink-0">
          <div className="relative flex-1 max-w-sm">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#4B6080]" />
            <input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search extensions, nodes, tags…"
              className="w-full bg-[#162032] border border-[#2A3F5C] rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#E2EAF4] placeholder-[#4B6080] focus:outline-none focus:border-[#3B82F6]" />
          </div>
          <div className="flex items-center gap-1.5 text-[10px] text-[#4B6080]">
            Sort:
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}
              className="bg-[#162032] border border-[#2A3F5C] rounded px-2 py-1 text-xs text-[#E2EAF4] focus:outline-none">
              <option>Downloads</option>
              <option>Stars</option>
              <option>Last Updated</option>
              <option>Name</option>
            </select>
          </div>
          <div className="flex-1" />
          <span className="text-xs text-[#4B6080]">{filtered.length} extensions</span>
          <button onClick={() => setPublishOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#3B82F6] hover:bg-[#2563EB] rounded text-white text-xs transition-colors">
            <Upload size={11} />Publish Extension
          </button>
        </div>

        {/* Tier info bar */}
        <div className="flex items-center gap-3 px-4 py-1.5 bg-[#0F1826] border-b border-[#1E2D42] overflow-x-auto shrink-0">
          {(Object.entries(TIER_CONFIG) as [Tier, typeof TIER_CONFIG[Tier]][]).map(([tier, config]) => (
            <div key={tier} className="flex items-center gap-1.5 shrink-0 text-[10px]" style={{ color: config.color }}>
              {config.icon}
              <span className="font-medium">{config.label}:</span>
              <span className="text-[#4B6080]">{config.desc}</span>
            </div>
          ))}
        </div>

        {/* Extension Grid */}
        <div className="flex-1 overflow-y-auto p-4">
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 gap-3">
              <Package size={32} className="text-[#2A3F5C]" />
              <p className="text-sm text-[#4B6080]">No extensions found</p>
              <p className="text-xs text-[#2A3F5C]">Try a different search or filter</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filtered.map((ext) => (
                <ExtCard key={ext.id} ext={ext}
                  onInstall={(id) => setInstalled((prev) => { const s = new Set(prev); s.has(id) ? s.delete(id) : s.add(id); return s; })} />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Publish Modal */}
      {publishOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-[#162032] border border-[#2A3F5C] rounded-2xl w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between p-5 border-b border-[#1E2D42]">
              <div>
                <h2 className="text-[#E2EAF4]">Publish Extension</h2>
                <p className="text-[11px] text-[#4B6080]">Submit to JuliaFlow Hub via Pkg.jl registry</p>
              </div>
              <button onClick={() => setPublishOpen(false)} className="text-[#4B6080] hover:text-[#E2EAF4]">
                <X size={16} />
              </button>
            </div>
            <div className="p-5 space-y-4">
              {[
                { label: "Package Name", placeholder: "JuliaFlow.MyExtension" },
                { label: "Julia Package URL (GitHub)", placeholder: "https://github.com/org/JuliaFlow-MyExt.jl" },
                { label: "Version", placeholder: "0.1.0" },
                { label: "Compatible JuliaFlow Version", placeholder: ">=1.0.0" },
              ].map((field) => (
                <div key={field.label}>
                  <label className="block text-[10px] text-[#6B8AAE] mb-1">{field.label}</label>
                  <input placeholder={field.placeholder}
                    className="w-full bg-[#1E2D42] border border-[#2A3F5C] rounded-lg px-3 py-2 text-xs text-[#E2EAF4] placeholder-[#4B6080] focus:outline-none focus:border-[#3B82F6]" />
                </div>
              ))}
              <div>
                <label className="block text-[10px] text-[#6B8AAE] mb-1">Tier Request</label>
                <select className="w-full bg-[#1E2D42] border border-[#2A3F5C] rounded-lg px-3 py-2 text-xs text-[#E2EAF4] focus:outline-none focus:border-[#3B82F6]">
                  <option>Community (Tier 3) — Self-published, no review required</option>
                  <option>Verified (Tier 2) — Apply for JuliaFlow team review</option>
                </select>
              </div>
            </div>
            <div className="flex gap-2 p-5 border-t border-[#1E2D42]">
              <button className="flex-1 py-2 bg-[#3B82F6] hover:bg-[#2563EB] rounded-lg text-white text-sm transition-colors">
                Submit for Review
              </button>
              <button onClick={() => setPublishOpen(false)}
                className="px-4 py-2 bg-[#1E2D42] hover:bg-[#2A3F5C] border border-[#2A3F5C] rounded-lg text-[#E2EAF4] text-sm transition-colors">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
