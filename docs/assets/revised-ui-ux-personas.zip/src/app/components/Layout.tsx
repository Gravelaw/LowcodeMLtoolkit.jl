import { NavLink, Outlet, useLocation } from "react-router";
import {
  Workflow,
  LayoutDashboard,
  Package,
  Activity,
  Settings,
  Zap,
  Bell,
  ChevronRight,
  User,
  Cpu,
} from "lucide-react";

const navItems = [
  {
    to: "/",
    icon: Workflow,
    label: "Workflow Canvas",
    persona: "Data Scientists · ML Engineers · Data Engineers",
    end: true,
  },
  {
    to: "/dashboard",
    icon: LayoutDashboard,
    label: "BI Dashboard",
    persona: "Business Analysts",
    end: false,
  },
  {
    to: "/hub",
    icon: Package,
    label: "JuliaFlow Hub",
    persona: "Extension Developers",
    end: false,
  },
  {
    to: "/monitor",
    icon: Activity,
    label: "Execution Monitor",
    persona: "DevOps · Platform Architects",
    end: false,
  },
  {
    to: "/settings",
    icon: Settings,
    label: "Settings",
    persona: "All Roles",
    end: false,
  },
];

const pageTitles: Record<string, { title: string; subtitle: string; persona: string; personaColor: string }> = {
  "/": {
    title: "Workflow Canvas",
    subtitle: "Visual Low-Code Analytics",
    persona: "Data Scientists · ML Engineers · Data Engineers",
    personaColor: "text-[#8B5CF6]",
  },
  "/dashboard": {
    title: "BI Dashboard",
    subtitle: "Integrated Business Intelligence Layer",
    persona: "Business Analysts",
    personaColor: "text-[#10B981]",
  },
  "/hub": {
    title: "JuliaFlow Hub",
    subtitle: "Extension & Workflow Marketplace",
    persona: "Extension Developers",
    personaColor: "text-[#F97316]",
  },
  "/monitor": {
    title: "Execution Monitor",
    subtitle: "GPU · CPU · Streaming Pipeline Observability",
    persona: "DevOps · Platform Architects",
    personaColor: "text-[#3B82F6]",
  },
  "/settings": {
    title: "Settings",
    subtitle: "Platform Configuration & Security",
    persona: "All Roles",
    personaColor: "text-[#6B7280]",
  },
};

export function Layout() {
  const location = useLocation();
  const page = pageTitles[location.pathname] ?? pageTitles["/"];

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#0F1826] text-[#E2EAF4]">
      {/* Left Icon Sidebar */}
      <aside className="flex flex-col items-center w-16 bg-[#0B1120] border-r border-[#1E2D42] py-4 gap-1 z-20 shrink-0">
        {/* Logo */}
        <div className="mb-4 flex flex-col items-center gap-1">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center">
            <Zap size={16} className="text-white" />
          </div>
        </div>
        <div className="w-8 h-px bg-[#1E2D42] mb-2" />

        {/* Nav Items */}
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            title={`${item.label}\n${item.persona}`}
            className={({ isActive }) =>
              `group relative flex flex-col items-center justify-center w-10 h-10 rounded-lg transition-all duration-150 
              ${isActive
                ? "bg-[#1E2D42] text-[#3B82F6]"
                : "text-[#4B6080] hover:bg-[#162032] hover:text-[#E2EAF4]"
              }`
            }
          >
            {({ isActive }) => (
              <>
                <item.icon size={18} />
                {isActive && (
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-6 bg-[#3B82F6] rounded-r" />
                )}
                {/* Tooltip */}
                <div className="pointer-events-none absolute left-full ml-2 px-2 py-1.5 bg-[#1E2D42] border border-[#2A3F5C] rounded text-[11px] whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity z-50 shadow-lg">
                  <div className="text-[#E2EAF4]">{item.label}</div>
                  <div className="text-[#4B6080] text-[10px]">{item.persona}</div>
                </div>
              </>
            )}
          </NavLink>
        ))}

        {/* Bottom: User Avatar */}
        <div className="mt-auto flex flex-col items-center gap-2">
          <button className="group relative w-10 h-10 rounded-lg flex items-center justify-center text-[#4B6080] hover:bg-[#162032] hover:text-[#E2EAF4] transition-all">
            <Bell size={16} />
            <div className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#3B82F6] rounded-full border border-[#0B1120]" />
          </button>
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center cursor-pointer">
            <User size={14} className="text-white" />
          </div>
        </div>
      </aside>

      {/* Main Area */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        {/* Top Bar */}
        <header className="flex items-center h-12 px-4 bg-[#0B1120] border-b border-[#1E2D42] shrink-0 gap-3">
          <div className="flex items-center gap-1.5 text-[#4B6080] text-xs">
            <span className="text-[#E2EAF4] font-semibold">JuliaFlow</span>
            <ChevronRight size={12} />
            <span>{page.title}</span>
          </div>
          <div className="flex-1" />
          {/* Persona badge */}
          <div className="flex items-center gap-2 px-3 py-1 bg-[#162032] border border-[#2A3F5C] rounded-full">
            <div className={`w-1.5 h-1.5 rounded-full bg-current ${page.personaColor}`} />
            <span className={`text-xs ${page.personaColor}`}>{page.persona}</span>
          </div>
          {/* GPU indicator */}
          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#162032] border border-[#2A3F5C] rounded text-[11px]">
            <Cpu size={11} className="text-[#EAB308]" />
            <span className="text-[#EAB308]">GPU</span>
            <span className="text-[#E2EAF4]">2 × A100</span>
          </div>
          {/* Connection status */}
          <div className="flex items-center gap-1.5 text-[11px] text-[#4B6080]">
            <div className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse" />
            <span>Connected</span>
          </div>
          {/* Version */}
          <span className="text-[11px] text-[#4B6080]">v1.0 · Julia 1.10+</span>
        </header>

        {/* Content */}
        <main className="flex-1 min-h-0 overflow-hidden">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
