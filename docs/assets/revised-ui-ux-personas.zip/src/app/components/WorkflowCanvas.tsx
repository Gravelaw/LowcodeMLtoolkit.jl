import { useState, useRef, useCallback, useEffect } from "react";
import {
  Play, Square, RotateCcw, Save, Plus, Search, ChevronDown,
  ChevronRight, FileText, Filter, Brain, BarChart2, Zap,
  Radio, GitBranch, Database, Code, SlidersHorizontal,
  Activity, Cpu, X, AlertCircle, CheckCircle, Clock,
  Settings2, Info, Layers, Table, TrendingUp, Scatter,
  Network, FlaskConical, Globe, Download, Upload,
  MoreHorizontal, Maximize2, PanelLeftClose, PanelRightClose,
  Terminal, RefreshCw,
} from "lucide-react";

// ── Types ──────────────────────────────────────────────────────────────────

type NodeState = "idle" | "configured" | "running" | "executed" | "error" | "streaming";
type NodeCategory = "io" | "transform" | "ml" | "stats" | "viz" | "gpu" | "streaming" | "control";

interface CanvasNode {
  id: string;
  label: string;
  category: NodeCategory;
  state: NodeState;
  x: number;
  y: number;
  description: string;
  config: Record<string, string>;
}

interface Connection {
  id: string;
  from: string;
  to: string;
  portType: "data" | "model" | "flow" | "streaming";
}

// ── Constants ─────────────────────────────────────────────────────────────

const NODE_W = 184;
const NODE_H = 62;

const CATEGORY_COLOR: Record<NodeCategory, string> = {
  io: "#3B82F6",
  transform: "#F97316",
  ml: "#8B5CF6",
  stats: "#EC4899",
  viz: "#6366F1",
  gpu: "#EAB308",
  streaming: "#06B6D4",
  control: "#6B7280",
};

const CATEGORY_LABEL: Record<NodeCategory, string> = {
  io: "Data I/O",
  transform: "Transform",
  ml: "Machine Learning",
  stats: "Statistics",
  viz: "Visualisation",
  gpu: "GPU",
  streaming: "Streaming",
  control: "Control Flow",
};

const STATE_COLOR: Record<NodeState, string> = {
  idle: "#4B5563",
  configured: "#F59E0B",
  running: "#3B82F6",
  executed: "#10B981",
  error: "#EF4444",
  streaming: "#06B6D4",
};

const STATE_LABEL: Record<NodeState, string> = {
  idle: "Idle",
  configured: "Configured",
  running: "Running",
  executed: "Executed",
  error: "Error",
  streaming: "Streaming Active",
};

const PORT_COLOR: Record<string, string> = {
  data: "#3B82F6",
  model: "#8B5CF6",
  flow: "#F59E0B",
  streaming: "#06B6D4",
};

// ── Initial Data ───────────────────────────────────────────────────────────

const INITIAL_NODES: CanvasNode[] = [
  // ML Pipeline
  { id: "n1", label: "CSV File Reader", category: "io", state: "executed", x: 60, y: 90, description: "Reads tabular data from CSV/TSV files with multi-threaded parsing.", config: { "File Path": "/data/sensor_readings.csv", "Delimiter": ",", "Has Headers": "true", "Encoding": "UTF-8" } },
  { id: "n2", label: "Row Filter", category: "transform", state: "executed", x: 300, y: 50, description: "Filters rows based on column conditions using Julia expression evaluator.", config: { "Condition": "value > 0.5", "Column": "sensor_output", "Mode": "Include" } },
  { id: "n3", label: "Normalizer", category: "transform", state: "executed", x: 300, y: 150, description: "Normalizes numeric columns to [0,1] or Z-score. GPU-accelerated for large tables.", config: { "Method": "Min-Max", "Columns": "All Numeric", "Execution Device": "CPU" } },
  { id: "n4", label: "Train/Test Split", category: "ml", state: "configured", x: 545, y: 100, description: "Splits data into training and test sets with stratification support.", config: { "Test Ratio": "0.2", "Stratify": "label", "Seed": "42", "Shuffle": "true" } },
  { id: "n5", label: "Random Forest", category: "ml", state: "idle", x: 790, y: 50, description: "Gradient-boosted Random Forest via EvoTrees.jl with GPU offload.", config: { "Trees": "100", "Max Depth": "6", "Learning Rate": "0.1", "Execution Device": "GPU Preferred" } },
  { id: "n6", label: "Model Evaluator", category: "ml", state: "idle", x: 1035, y: 100, description: "Evaluates model performance with Accuracy, F1, AUC-ROC, Confusion Matrix.", config: { "Metrics": "Accuracy, F1, AUC", "Output Table": "true", "Plot Confusion Matrix": "true" } },
  { id: "n7", label: "Scatter Plot", category: "viz", state: "idle", x: 1280, y: 100, description: "Interactive scatter chart for visualizing model predictions vs ground truth.", config: { "X Column": "predicted", "Y Column": "actual", "Color By": "label" } },
  // GPU branch
  { id: "n8", label: "GPU Array Transfer", category: "gpu", state: "idle", x: 790, y: 170, description: "Transfers Arrow columnar data to GPU memory as CuArray/ROCArray.", config: { "Target Device": "CUDA:0 (NVIDIA A100)", "Data Type": "Float32", "Async": "true" } },
  // Streaming pipeline
  { id: "n9",  label: "Kafka Consumer", category: "streaming", state: "streaming", x: 60, y: 310, description: "Consumes records from Apache Kafka with Avro/JSON/Protobuf deserialization.", config: { "Topic": "iot.sensors.raw", "Group ID": "juliaflow-wf-001", "Offset Policy": "latest", "Deserialization": "Avro" } },
  { id: "n10", label: "JSON Parser",     category: "transform",  state: "running",  x: 300, y: 310, description: "Parses JSON payloads into typed Arrow schema columns.", config: { "Schema Inference": "true", "Null Handling": "Replace with Missing" } },
  { id: "n11", label: "Field Mapper",    category: "transform",  state: "executed", x: 545, y: 310, description: "Renames, reorders, and type-casts columns per a mapping specification.", config: { "Mapping": "timestamp→ts, value→sensor_val", "Drop Unmapped": "true" } },
  { id: "n12", label: "DB Writer",       category: "io",         state: "error",    x: 790, y: 310, description: "Writes output rows to a configured database via JDBC connector.", config: { "Driver": "PostgreSQL", "Table": "analytics.sensor_stream", "Mode": "Append" } },
  { id: "n13", label: "BI Outlet",       category: "viz",        state: "streaming",x: 1035, y: 310, description: "Tags this node's output as a BI Data Outlet for live dashboard binding.", config: { "Outlet Name": "sensor_live_feed", "Chart Types": "Line, KPI Card" } },
  // Control flow
  { id: "n14", label: "Loop Start",      category: "control",    state: "configured", x: 60, y: 510, description: "Iterates over parameter ranges, table chunks, or file lists.", config: { "Mode": "Parameter Range", "Parameter": "threshold", "From": "0.1", "To": "0.9", "Step": "0.1" } },
  { id: "n15", label: "Hyperopt Node",   category: "ml",         state: "idle",       x: 300, y: 510, description: "Bayesian hyperparameter search via Hyperopt.jl with parallel trials.", config: { "Strategy": "Bayesian", "Trials": "50", "Parallelism": "4", "Metric": "F1 Score" } },
  { id: "n16", label: "Loop End",        category: "control",    state: "configured", x: 545, y: 510, description: "Closes an iterative loop and collects results across all iterations.", config: { "Collect": "All Iterations", "Aggregation": "Best F1" } },
];

const INITIAL_CONNECTIONS: Connection[] = [
  { id: "c1",  from: "n1", to: "n2",  portType: "data" },
  { id: "c2",  from: "n1", to: "n3",  portType: "data" },
  { id: "c3",  from: "n2", to: "n4",  portType: "data" },
  { id: "c4",  from: "n3", to: "n4",  portType: "data" },
  { id: "c5",  from: "n4", to: "n5",  portType: "data" },
  { id: "c6",  from: "n4", to: "n6",  portType: "data" },
  { id: "c7",  from: "n5", to: "n6",  portType: "model" },
  { id: "c8",  from: "n5", to: "n8",  portType: "model" },
  { id: "c9",  from: "n6", to: "n7",  portType: "data" },
  { id: "c10", from: "n9",  to: "n10", portType: "streaming" },
  { id: "c11", from: "n10", to: "n11", portType: "streaming" },
  { id: "c12", from: "n11", to: "n12", portType: "data" },
  { id: "c13", from: "n11", to: "n13", portType: "streaming" },
  { id: "c14", from: "n14", to: "n15", portType: "flow" },
  { id: "c15", from: "n15", to: "n16", portType: "data" },
  { id: "c16", from: "n14", to: "n16", portType: "flow" },
];

// ── Node Repository ────────────────────────────────────────────────────────

const NODE_REPO = [
  { category: "io" as NodeCategory, label: "Data I/O", nodes: ["CSV File Reader", "Parquet Reader", "Database Connector", "Kafka Consumer", "Kafka Producer", "NATS Subscriber", "S3 Reader", "HTTP Request", "WebSocket Client"] },
  { category: "transform" as NodeCategory, label: "Transform", nodes: ["Row Filter", "Column Filter", "Normalizer", "Group By", "Join", "Pivot", "String Replacer", "DateTime Parser", "Missing Value Imputer", "Type Cast"] },
  { category: "ml" as NodeCategory, label: "Machine Learning", nodes: ["Random Forest", "Gradient Boost", "Linear Regression", "SVM", "k-NN", "Train/Test Split", "Cross-Validation", "Model Evaluator", "Hyperopt", "AutoML"] },
  { category: "stats" as NodeCategory, label: "Statistics", nodes: ["Descriptive Stats", "Correlation Matrix", "Hypothesis Testing", "PCA", "t-SNE", "UMAP", "Bayesian Inference", "Monte Carlo"] },
  { category: "viz" as NodeCategory, label: "Visualisation", nodes: ["Scatter Plot", "Bar Chart", "Line Chart", "Heatmap", "Box Plot", "Choropleth Map", "Network Graph", "Sankey Diagram", "BI Outlet"] },
  { category: "gpu" as NodeCategory, label: "GPU Nodes", nodes: ["GPU Array Transfer", "GPU Matrix Ops", "GPU Custom Kernel", "GPU Profiler", "GPU Memory Manager", "Flux.jl Trainer", "cuFFT Node"] },
  { category: "streaming" as NodeCategory, label: "Streaming", nodes: ["Tumbling Window", "Sliding Window", "Watermark", "Stream Join", "Stream Aggregator", "Checkpoint Node"] },
  { category: "control" as NodeCategory, label: "Control Flow", nodes: ["Loop Start", "Loop End", "Case Switch", "Try Node", "Catch Node", "Parallel Chunk", "Flow Variable Inject"] },
];

const CATEGORY_ICON: Record<NodeCategory, React.ReactNode> = {
  io: <Database size={12} />,
  transform: <Filter size={12} />,
  ml: <Brain size={12} />,
  stats: <BarChart2 size={12} />,
  viz: <TrendingUp size={12} />,
  gpu: <Zap size={12} />,
  streaming: <Radio size={12} />,
  control: <GitBranch size={12} />,
};

const LOG_ENTRIES = [
  { time: "14:23:41", level: "info",  msg: "Workflow execution started — 13 nodes queued" },
  { time: "14:23:41", level: "info",  msg: "[n1] CSV File Reader: reading /data/sensor_readings.csv (2.4M rows)" },
  { time: "14:23:42", level: "info",  msg: "[n1] Executed — 2,401,024 rows, 18 columns — 1.24s" },
  { time: "14:23:42", level: "info",  msg: "[n2] Row Filter: applying condition `sensor_output > 0.5`" },
  { time: "14:23:42", level: "info",  msg: "[n3] Normalizer: min-max on 12 numeric columns — dispatching CPU multi-threaded" },
  { time: "14:23:43", level: "info",  msg: "[n2] Executed — 1,847,302 rows retained (76.9%) — 0.87s" },
  { time: "14:23:43", level: "info",  msg: "[n3] Executed — normalization complete — 0.91s" },
  { time: "14:23:43", level: "info",  msg: "[n4] Train/Test Split: 80/20, stratify=label, seed=42" },
  { time: "14:23:43", level: "info",  msg: "[n4] Configured — awaiting execution" },
  { time: "14:23:44", level: "stream","msg": "[n9] Kafka Consumer ACTIVE — topic=iot.sensors.raw, offset=latest" },
  { time: "14:23:44", level: "stream","msg": "[n9→n10] Streaming: 4,821 records/s — p99 latency 38ms" },
  { time: "14:23:44", level: "warn",  msg: "[n10] JSON Parser: 3 malformed records skipped (null sensor_id)" },
  { time: "14:23:45", level: "error", msg: "[n12] DB Writer: Connection refused — PostgreSQL host unreachable" },
  { time: "14:23:45", level: "error", msg: "[n12] Execution failed — JDBC connection timeout after 5000ms" },
];

// ── Edge path helper ────────────────────────────────────────────────────────

function getEdgePath(from: CanvasNode, to: CanvasNode): string {
  const x1 = from.x + NODE_W;
  const y1 = from.y + NODE_H / 2;
  const x2 = to.x;
  const y2 = to.y + NODE_H / 2;
  const dx = Math.max(Math.abs(x2 - x1) * 0.45, 40);
  return `M ${x1} ${y1} C ${x1 + dx} ${y1} ${x2 - dx} ${y2} ${x2} ${y2}`;
}

// ── WorkflowCanvas Component ───────────────────────────────────────────────

export function WorkflowCanvas() {
  const [nodes, setNodes] = useState<CanvasNode[]>(INITIAL_NODES);
  const [connections] = useState<Connection[]>(INITIAL_CONNECTIONS);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [repoSearch, setRepoSearch] = useState("");
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set(["io", "transform", "ml"]));
  const [showRepo, setShowRepo] = useState(true);
  const [showProps, setShowProps] = useState(true);
  const [showLog, setShowLog] = useState(true);
  const [running, setRunning] = useState(false);
  const [activeTab, setActiveTab] = useState<"config" | "ports" | "info">("config");
  const canvasRef = useRef<HTMLDivElement>(null);
  const dragging = useRef<{ id: string; ox: number; oy: number } | null>(null);

  const selected = nodes.find((n) => n.id === selectedNode) ?? null;

  // Run workflow simulation
  const runWorkflow = useCallback(() => {
    if (running) return;
    setRunning(true);
    const sequence = ["n4", "n5", "n8", "n6", "n7", "n15", "n16"];
    let delay = 0;
    setNodes((prev) => prev.map((n) => sequence.includes(n.id) ? { ...n, state: "configured" } : n));
    sequence.forEach((id, i) => {
      delay += 600 + Math.random() * 400;
      setTimeout(() => {
        setNodes((prev) => prev.map((n) => n.id === id ? { ...n, state: "running" } : n));
      }, delay);
      delay += 800 + Math.random() * 600;
      setTimeout(() => {
        setNodes((prev) => prev.map((n) => n.id === id ? { ...n, state: "executed" } : n));
        if (i === sequence.length - 1) setRunning(false);
      }, delay);
    });
  }, [running]);

  const resetWorkflow = () => {
    setNodes(INITIAL_NODES);
    setRunning(false);
    setSelectedNode(null);
  };

  // Drag logic
  const onMouseDown = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const node = nodes.find((n) => n.id === id)!;
    dragging.current = { id, ox: e.clientX - node.x, oy: e.clientY - node.y };
  };

  const onMouseMove = useCallback((e: MouseEvent) => {
    if (!dragging.current) return;
    const { id, ox, oy } = dragging.current;
    setNodes((prev) => prev.map((n) => n.id === id ? { ...n, x: e.clientX - ox, y: e.clientY - oy } : n));
  }, []);

  const onMouseUp = useCallback(() => { dragging.current = null; }, []);

  useEffect(() => {
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
    };
  }, [onMouseMove, onMouseUp]);

  const toggleCategory = (cat: string) => {
    setExpandedCategories((prev) => {
      const next = new Set(prev);
      if (next.has(cat)) next.delete(cat); else next.add(cat);
      return next;
    });
  };

  const filteredRepo = NODE_REPO.map((cat) => ({
    ...cat,
    nodes: cat.nodes.filter((n) => n.toLowerCase().includes(repoSearch.toLowerCase())),
  })).filter((cat) => cat.nodes.length > 0);

  return (
    <div className="flex flex-col h-full bg-[#0F1826]">
      {/* Toolbar */}
      <div className="flex items-center h-10 px-3 bg-[#0B1120] border-b border-[#1E2D42] gap-2 shrink-0">
        <div className="flex items-center gap-1 mr-2">
          <span className="text-xs text-[#E2EAF4] max-w-40 truncate">ML_Sensor_Pipeline_v3.jlflow</span>
          <span className="text-[10px] text-[#4B6080] border border-[#2A3F5C] rounded px-1">Batch</span>
        </div>
        <div className="w-px h-5 bg-[#1E2D42]" />
        <button onClick={runWorkflow} disabled={running}
          className="flex items-center gap-1.5 px-3 py-1 bg-[#10B981] hover:bg-[#059669] disabled:opacity-50 disabled:cursor-not-allowed rounded text-white text-xs transition-colors">
          {running ? <RefreshCw size={12} className="animate-spin" /> : <Play size={12} />}
          {running ? "Running…" : "Run Workflow"}
        </button>
        <button onClick={resetWorkflow}
          className="flex items-center gap-1.5 px-2.5 py-1 bg-[#162032] hover:bg-[#1E2D42] border border-[#2A3F5C] rounded text-[#E2EAF4] text-xs transition-colors">
          <RotateCcw size={12} />Reset
        </button>
        <button className="flex items-center gap-1.5 px-2.5 py-1 bg-[#162032] hover:bg-[#1E2D42] border border-[#2A3F5C] rounded text-[#E2EAF4] text-xs transition-colors">
          <Save size={12} />Save
        </button>
        <div className="flex-1" />
        {/* State legend */}
        {(["executed","configured","running","streaming","error","idle"] as NodeState[]).map((s) => (
          <div key={s} className="flex items-center gap-1 text-[10px] text-[#6B8AAE]">
            <div className={`w-2 h-2 rounded-full ${s === "running" || s === "streaming" ? "animate-pulse" : ""}`} style={{ background: STATE_COLOR[s] }} />
            {STATE_LABEL[s]}
          </div>
        ))}
        <div className="w-px h-5 bg-[#1E2D42]" />
        <button onClick={() => setShowRepo((v) => !v)} title="Toggle Node Repository"
          className="p-1.5 text-[#4B6080] hover:text-[#E2EAF4] rounded hover:bg-[#162032] transition-colors">
          <PanelLeftClose size={14} />
        </button>
        <button onClick={() => setShowProps((v) => !v)} title="Toggle Properties"
          className="p-1.5 text-[#4B6080] hover:text-[#E2EAF4] rounded hover:bg-[#162032] transition-colors">
          <PanelRightClose size={14} />
        </button>
      </div>

      {/* Main Layout */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* Node Repository */}
        {showRepo && (
          <div className="w-56 shrink-0 flex flex-col bg-[#0B1120] border-r border-[#1E2D42] overflow-hidden">
            <div className="p-2 border-b border-[#1E2D42]">
              <div className="relative">
                <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-[#4B6080]" />
                <input value={repoSearch} onChange={(e) => setRepoSearch(e.target.value)}
                  placeholder="Search nodes…"
                  className="w-full bg-[#162032] border border-[#2A3F5C] rounded pl-6 pr-2 py-1.5 text-xs text-[#E2EAF4] placeholder-[#4B6080] focus:outline-none focus:border-[#3B82F6]" />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto py-1">
              {filteredRepo.map((cat) => (
                <div key={cat.category}>
                  <button onClick={() => toggleCategory(cat.category)}
                    className="flex items-center gap-2 w-full px-3 py-1.5 text-[#6B8AAE] hover:text-[#E2EAF4] hover:bg-[#162032] transition-colors">
                    <span style={{ color: CATEGORY_COLOR[cat.category] }}>{CATEGORY_ICON[cat.category]}</span>
                    <span className="text-[11px] flex-1 text-left">{cat.label}</span>
                    <span className="text-[10px] text-[#4B6080]">{cat.nodes.length}</span>
                    {expandedCategories.has(cat.category)
                      ? <ChevronDown size={10} />
                      : <ChevronRight size={10} />}
                  </button>
                  {expandedCategories.has(cat.category) && (
                    <div className="pb-1">
                      {cat.nodes.map((node) => (
                        <div key={node}
                          className="flex items-center gap-2 pl-8 pr-3 py-1 text-[11px] text-[#8BA3C0] hover:bg-[#162032] hover:text-[#E2EAF4] cursor-grab transition-colors rounded mx-1">
                          <div className="w-1 h-1 rounded-full shrink-0" style={{ background: CATEGORY_COLOR[cat.category] }} />
                          {node}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
            <div className="p-2 border-t border-[#1E2D42]">
              <button className="flex items-center gap-2 w-full px-2 py-1.5 bg-[#162032] hover:bg-[#1E2D42] border border-dashed border-[#2A3F5C] rounded text-[11px] text-[#4B6080] hover:text-[#E2EAF4] transition-colors">
                <Plus size={11} /> Browse JuliaFlow Hub
              </button>
            </div>
          </div>
        )}

        {/* Canvas Area + Log */}
        <div className="flex flex-col flex-1 min-w-0 min-h-0 overflow-hidden">
          {/* Canvas */}
          <div className="flex-1 overflow-auto relative bg-[#0F1826]"
            style={{ backgroundImage: "radial-gradient(circle, #1E2D42 1px, transparent 1px)", backgroundSize: "28px 28px" }}
            onClick={() => setSelectedNode(null)}>

            {/* Canvas inner: 2500×1100 */}
            <div ref={canvasRef} className="relative" style={{ width: 2500, height: 1100, userSelect: "none" }}>
              {/* SVG edges */}
              <svg className="absolute inset-0 pointer-events-none" width={2500} height={1100}>
                <defs>
                  {Object.entries(PORT_COLOR).map(([type, color]) => (
                    <marker key={type} id={`arrow-${type}`} markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
                      <path d="M 0 0 L 6 3 L 0 6 z" fill={color} opacity={0.8} />
                    </marker>
                  ))}
                </defs>
                {connections.map((conn) => {
                  const from = nodes.find((n) => n.id === conn.from);
                  const to = nodes.find((n) => n.id === conn.to);
                  if (!from || !to) return null;
                  const color = PORT_COLOR[conn.portType];
                  const isActive = from.state === "running" || from.state === "streaming";
                  return (
                    <path key={conn.id}
                      d={getEdgePath(from, to)}
                      fill="none"
                      stroke={color}
                      strokeWidth={isActive ? 2 : 1.5}
                      strokeOpacity={isActive ? 0.9 : 0.4}
                      strokeDasharray={conn.portType === "flow" ? "5,3" : undefined}
                      markerEnd={`url(#arrow-${conn.portType})`}
                    />
                  );
                })}
              </svg>

              {/* Section labels */}
              <div className="absolute text-[10px] text-[#4B6080] font-mono" style={{ left: 60, top: 60 }}>
                ▸ ML TRAINING PIPELINE (Batch)
              </div>
              <div className="absolute text-[10px] text-[#4B6080] font-mono" style={{ left: 60, top: 280 }}>
                ▸ IOT SENSOR INGESTION (Streaming — Kafka → DB)
              </div>
              <div className="absolute text-[10px] text-[#4B6080] font-mono" style={{ left: 60, top: 480 }}>
                ▸ HYPERPARAMETER OPTIMISATION LOOP (Control Flow)
              </div>

              {/* Nodes */}
              {nodes.map((node) => {
                const catColor = CATEGORY_COLOR[node.category];
                const stateColor = STATE_COLOR[node.state];
                const isSelected = selectedNode === node.id;
                const isRunning = node.state === "running" || node.state === "streaming";
                return (
                  <div key={node.id}
                    style={{ left: node.x, top: node.y, width: NODE_W, height: NODE_H, boxShadow: isRunning ? `0 0 12px ${stateColor}40` : undefined }}
                    className={`absolute rounded-lg border cursor-pointer select-none transition-shadow
                      ${isSelected
                        ? "border-[#3B82F6] shadow-lg shadow-blue-500/30 bg-[#1E2D42]"
                        : "border-[#2A3F5C] hover:border-[#3B82F6]/60 bg-[#162032]"}
                      ${isRunning ? "shadow-md" : ""}
                    `}
                    onClick={(e) => { e.stopPropagation(); setSelectedNode(node.id); }}
                    onMouseDown={(e) => onMouseDown(e, node.id)}>

                    {/* Category stripe */}
                    <div className="absolute left-0 top-0 bottom-0 w-1 rounded-l-lg" style={{ background: catColor }} />

                    {/* Input port */}
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full border-2"
                      style={{ background: "#162032", borderColor: catColor }} />

                    {/* Output port */}
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-2.5 h-2.5 rounded-full border-2"
                      style={{ background: "#162032", borderColor: catColor }} />

                    {/* State dot */}
                    <div className={`absolute top-2 right-2 w-2 h-2 rounded-full ${isRunning ? "animate-pulse" : ""}`}
                      style={{ background: stateColor }} />

                    {/* GPU badge */}
                    {(node.category === "gpu" || node.config["Execution Device"]?.includes("GPU")) && (
                      <div className="absolute top-2 right-5 text-[9px] text-[#EAB308] font-mono">GPU</div>
                    )}

                    {/* Content */}
                    <div className="flex items-center h-full pl-4 pr-6 gap-2">
                      <span style={{ color: catColor }} className="shrink-0">
                        {CATEGORY_ICON[node.category]}
                      </span>
                      <div className="min-w-0">
                        <p className="text-xs text-[#E2EAF4] truncate leading-tight">{node.label}</p>
                        <p className="text-[10px] text-[#4B6080]">{CATEGORY_LABEL[node.category]}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Log Panel */}
          {showLog && (
            <div className="h-36 shrink-0 border-t border-[#1E2D42] bg-[#0B1120] flex flex-col">
              <div className="flex items-center gap-2 px-3 py-1 border-b border-[#1E2D42]">
                <Terminal size={11} className="text-[#4B6080]" />
                <span className="text-[11px] text-[#6B8AAE]">Execution Log</span>
                <div className="flex-1" />
                <span className="text-[10px] text-[#4B6080]">{LOG_ENTRIES.length} entries</span>
                <button onClick={() => setShowLog(false)} className="text-[#4B6080] hover:text-[#E2EAF4]"><X size={12} /></button>
              </div>
              <div className="flex-1 overflow-y-auto px-3 py-1 font-mono">
                {LOG_ENTRIES.map((entry, i) => (
                  <div key={i} className="flex items-start gap-2 text-[10px] py-0.5">
                    <span className="text-[#4B6080] shrink-0">{entry.time}</span>
                    <span className={`shrink-0 w-12 ${entry.level === "error" ? "text-[#EF4444]" : entry.level === "warn" ? "text-[#F59E0B]" : entry.level === "stream" ? "text-[#06B6D4]" : "text-[#10B981]"}`}>
                      [{entry.level}]
                    </span>
                    <span className={entry.level === "error" ? "text-[#EF4444]" : entry.level === "warn" ? "text-[#F59E0B]/80" : entry.level === "stream" ? "text-[#06B6D4]/80" : "text-[#6B8AAE]"}>
                      {entry.msg}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Properties Panel */}
        {showProps && (
          <div className="w-64 shrink-0 flex flex-col bg-[#0B1120] border-l border-[#1E2D42] overflow-hidden">
            {selected ? (
              <>
                {/* Node header */}
                <div className="p-3 border-b border-[#1E2D42]">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <p className="text-xs text-[#E2EAF4]">{selected.label}</p>
                      <p className="text-[10px] text-[#4B6080]">{CATEGORY_LABEL[selected.category]}</p>
                    </div>
                    <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px]"
                      style={{ background: STATE_COLOR[selected.state] + "22", color: STATE_COLOR[selected.state] }}>
                      <div className={`w-1.5 h-1.5 rounded-full ${selected.state === "running" || selected.state === "streaming" ? "animate-pulse" : ""}`}
                        style={{ background: STATE_COLOR[selected.state] }} />
                      {STATE_LABEL[selected.state]}
                    </div>
                  </div>
                  {/* Tabs */}
                  <div className="flex gap-1">
                    {(["config", "ports", "info"] as const).map((tab) => (
                      <button key={tab} onClick={() => setActiveTab(tab)}
                        className={`px-2 py-0.5 rounded text-[10px] transition-colors capitalize
                          ${activeTab === tab ? "bg-[#1E2D42] text-[#3B82F6]" : "text-[#4B6080] hover:text-[#E2EAF4]"}`}>
                        {tab}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto p-3">
                  {activeTab === "config" && (
                    <div className="space-y-3">
                      {Object.entries(selected.config).map(([key, val]) => (
                        <div key={key}>
                          <label className="block text-[10px] text-[#6B8AAE] mb-1">{key}</label>
                          <input defaultValue={val}
                            className="w-full bg-[#162032] border border-[#2A3F5C] rounded px-2 py-1.5 text-xs text-[#E2EAF4] focus:outline-none focus:border-[#3B82F6]" />
                        </div>
                      ))}
                      {/* Execution device */}
                      <div>
                        <label className="block text-[10px] text-[#6B8AAE] mb-1">Execution Device</label>
                        <select className="w-full bg-[#162032] border border-[#2A3F5C] rounded px-2 py-1.5 text-xs text-[#E2EAF4] focus:outline-none focus:border-[#3B82F6]">
                          <option>Auto (JEP decides)</option>
                          <option>CPU Only</option>
                          <option>GPU Preferred</option>
                          <option>GPU Required (CUDA:0)</option>
                          <option>GPU Required (CUDA:1)</option>
                        </select>
                      </div>
                    </div>
                  )}
                  {activeTab === "ports" && (
                    <div className="space-y-3">
                      <div>
                        <p className="text-[10px] text-[#6B8AAE] mb-2">Input Ports</p>
                        <div className="space-y-1.5">
                          {[{ name: "Data Table", type: "data" }, { name: "Flow Variable", type: "flow" }].map((p) => (
                            <div key={p.name} className="flex items-center gap-2 p-2 bg-[#162032] rounded border border-[#2A3F5C]">
                              <div className="w-2 h-2 rounded-full" style={{ background: PORT_COLOR[p.type] }} />
                              <span className="text-xs text-[#E2EAF4]">{p.name}</span>
                              <span className="ml-auto text-[10px] text-[#4B6080]">{p.type}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div>
                        <p className="text-[10px] text-[#6B8AAE] mb-2">Output Ports</p>
                        <div className="space-y-1.5">
                          {[{ name: "Data Table", type: "data" }, { name: "Model", type: "model" }].map((p) => (
                            <div key={p.name} className="flex items-center gap-2 p-2 bg-[#162032] rounded border border-[#2A3F5C]">
                              <div className="w-2 h-2 rounded-full" style={{ background: PORT_COLOR[p.type] }} />
                              <span className="text-xs text-[#E2EAF4]">{p.name}</span>
                              <span className="ml-auto text-[10px] text-[#4B6080]">{p.type}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                  {activeTab === "info" && (
                    <div className="space-y-3 text-xs">
                      <p className="text-[#8BA3C0] leading-relaxed">{selected.description}</p>
                      <div className="space-y-1">
                        {[
                          ["Node ID", selected.id],
                          ["Category", CATEGORY_LABEL[selected.category]],
                          ["Julia Module", `JuliaFlow.${CATEGORY_LABEL[selected.category].replace(/\s/g,"")}.${selected.label.replace(/\s/g,"")}`],
                          ["Extension", "JuliaFlow Base (Tier 1)"],
                          ["Version", "1.0.0"],
                        ].map(([k, v]) => (
                          <div key={k} className="flex gap-2">
                            <span className="text-[#4B6080] w-24 shrink-0">{k}</span>
                            <span className="text-[#8BA3C0] font-mono truncate">{v}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="p-3 border-t border-[#1E2D42] flex gap-2">
                  <button className="flex-1 py-1.5 bg-[#3B82F6] hover:bg-[#2563EB] rounded text-white text-xs transition-colors">Apply</button>
                  <button className="px-3 py-1.5 bg-[#162032] hover:bg-[#1E2D42] border border-[#2A3F5C] rounded text-[#E2EAF4] text-xs transition-colors">Reset</button>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-full gap-3 p-6 text-center">
                <div className="w-12 h-12 rounded-xl bg-[#162032] border border-[#2A3F5C] flex items-center justify-center">
                  <Layers size={20} className="text-[#4B6080]" />
                </div>
                <div>
                  <p className="text-xs text-[#6B8AAE]">Select a node to configure it</p>
                  <p className="text-[10px] text-[#4B6080] mt-1">Click any node on the canvas to view its properties and execution settings.</p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}