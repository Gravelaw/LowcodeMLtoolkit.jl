import { useState } from "react";
import {
  Shield, Server, Key, Users, Cpu, Database, Bell, Globe,
  ChevronRight, Check, Toggle, Zap, Lock, RefreshCw, Eye, EyeOff,
} from "lucide-react";

const SECTIONS = [
  { id: "security", label: "Security & Auth", icon: <Shield size={14} /> },
  { id: "execution", label: "Execution Engine", icon: <Cpu size={14} /> },
  { id: "connections", label: "Data Connections", icon: <Database size={14} /> },
  { id: "users", label: "Users & RBAC", icon: <Users size={14} /> },
  { id: "notifications", label: "Notifications", icon: <Bell size={14} /> },
  { id: "platform", label: "Platform Info", icon: <Globe size={14} /> },
];

function Toggle2({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!value)}
      className={`relative w-9 h-5 rounded-full transition-colors ${value ? "bg-[#3B82F6]" : "bg-[#2A3F5C]"}`}>
      <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${value ? "translate-x-4" : "translate-x-0.5"}`} />
    </button>
  );
}

function SettingRow({ label, desc, children }: { label: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-[#1E2D42] last:border-0">
      <div>
        <p className="text-sm text-[#E2EAF4]">{label}</p>
        {desc && <p className="text-[10px] text-[#4B6080] mt-0.5 max-w-md">{desc}</p>}
      </div>
      <div className="ml-4 shrink-0">{children}</div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-[#162032] border border-[#2A3F5C] rounded-xl overflow-hidden">
      <div className="px-5 py-3 border-b border-[#1E2D42] bg-[#1E2D42]/50">
        <h3 className="text-[#E2EAF4]">{title}</h3>
      </div>
      <div className="px-5">{children}</div>
    </div>
  );
}

export function Settings() {
  const [active, setActive] = useState("security");
  const [tls, setTls] = useState(true);
  const [sso, setSso] = useState(true);
  const [audit, setAudit] = useState(true);
  const [sandbox, setSandbox] = useState(true);
  const [gpuAutoAssign, setGpuAutoAssign] = useState(true);
  const [streamCheckpoint, setStreamCheckpoint] = useState(true);
  const [showKey, setShowKey] = useState(false);

  return (
    <div className="flex h-full bg-[#0F1826] overflow-hidden">
      {/* Sidebar */}
      <div className="w-52 shrink-0 bg-[#0B1120] border-r border-[#1E2D42] py-3 overflow-y-auto">
        <p className="text-[10px] text-[#4B6080] px-4 mb-2">Platform Settings</p>
        {SECTIONS.map((s) => (
          <button key={s.id} onClick={() => setActive(s.id)}
            className={`flex items-center gap-2.5 w-full px-4 py-2 text-xs transition-colors
              ${active === s.id ? "bg-[#162032] text-[#3B82F6] border-r-2 border-[#3B82F6]" : "text-[#6B8AAE] hover:bg-[#162032] hover:text-[#E2EAF4]"}`}>
            {s.icon}{s.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {active === "security" && (
          <>
            <Section title="Authentication & OAuth 2.0 / OIDC">
              <SettingRow label="TLS 1.3 Enforcement" desc="All REST and WebSocket traffic requires TLS 1.3 minimum. HTTP connections are rejected.">
                <Toggle2 value={tls} onChange={setTls} />
              </SettingRow>
              <SettingRow label="SSO / Enterprise OIDC" desc="Delegate authentication to Keycloak with support for Azure AD, Google Workspace, Okta, and SAML 2.0.">
                <Toggle2 value={sso} onChange={setSso} />
              </SettingRow>
              <SettingRow label="JWT Token TTL" desc="Access token lifetime. Refresh tokens stored in HTTP-only SameSite=Strict cookies.">
                <select className="bg-[#1E2D42] border border-[#2A3F5C] rounded px-2 py-1 text-xs text-[#E2EAF4] focus:outline-none">
                  <option>1 hour</option>
                  <option>4 hours</option>
                  <option>8 hours</option>
                  <option>24 hours</option>
                </select>
              </SettingRow>
              <SettingRow label="OIDC Provider URL">
                <input defaultValue="https://auth.juliaflow.internal/realms/juliaflow"
                  className="w-64 bg-[#1E2D42] border border-[#2A3F5C] rounded px-2 py-1 text-xs text-[#E2EAF4] focus:outline-none focus:border-[#3B82F6]" />
              </SettingRow>
            </Section>

            <Section title="Node Execution Sandboxing (NFR-SEC-03)">
              <SettingRow label="Script Node Sandbox" desc="Julia Script and SQL Script nodes execute in isolated OCI containers (nsjail/gVisor) with cgroup resource limits.">
                <Toggle2 value={sandbox} onChange={setSandbox} />
              </SettingRow>
              <SettingRow label="Sandbox CPU Quota (cores)" desc="Maximum CPU cores per script node execution.">
                <input type="number" defaultValue={4} min={1} max={32}
                  className="w-20 bg-[#1E2D42] border border-[#2A3F5C] rounded px-2 py-1 text-xs text-[#E2EAF4] focus:outline-none text-center" />
              </SettingRow>
              <SettingRow label="Sandbox RAM Limit (GB)" desc="Maximum RAM per sandboxed execution. OOM-kill triggers graceful error state.">
                <input type="number" defaultValue={8} min={1} max={256}
                  className="w-20 bg-[#1E2D42] border border-[#2A3F5C] rounded px-2 py-1 text-xs text-[#E2EAF4] focus:outline-none text-center" />
              </SettingRow>
            </Section>

            <Section title="Secrets Management">
              <SettingRow label="Secret Backend" desc="Credentials stored as references resolved at execution time. Never stored in workflow TOML.">
                <select className="bg-[#1E2D42] border border-[#2A3F5C] rounded px-2 py-1 text-xs text-[#E2EAF4]">
                  <option>HashiCorp Vault</option>
                  <option>AWS Secrets Manager</option>
                  <option>Azure Key Vault</option>
                </select>
              </SettingRow>
              <SettingRow label="Vault Address">
                <input defaultValue="https://vault.internal:8200"
                  className="w-64 bg-[#1E2D42] border border-[#2A3F5C] rounded px-2 py-1 text-xs text-[#E2EAF4] focus:outline-none focus:border-[#3B82F6]" />
              </SettingRow>
              <SettingRow label="Vault Token (masked)">
                <div className="flex items-center gap-2">
                  <input type={showKey ? "text" : "password"} defaultValue="s.ABCDEFxyz1234567890"
                    className="w-48 bg-[#1E2D42] border border-[#2A3F5C] rounded px-2 py-1 text-xs text-[#E2EAF4] focus:outline-none" />
                  <button onClick={() => setShowKey(!showKey)} className="text-[#4B6080] hover:text-[#E2EAF4]">
                    {showKey ? <EyeOff size={13} /> : <Eye size={13} />}
                  </button>
                </div>
              </SettingRow>
              <SettingRow label="Audit Logging (SOC 2 Type II)" desc="Immutable append-only log of all workflow executions, access events, and user actions.">
                <Toggle2 value={audit} onChange={setAudit} />
              </SettingRow>
            </Section>
          </>
        )}

        {active === "execution" && (
          <>
            <Section title="JuliaFlow Execution Planner (JEP)">
              <SettingRow label="Auto GPU Assignment" desc="JEP automatically assigns gpu_preferred nodes to available GPU devices based on VRAM budget analysis.">
                <Toggle2 value={gpuAutoAssign} onChange={setGpuAutoAssign} />
              </SettingRow>
              <SettingRow label="Default GPU Profile">
                <select className="bg-[#1E2D42] border border-[#2A3F5C] rounded px-2 py-1 text-xs text-[#E2EAF4]">
                  <option>Auto (JEP Decides)</option>
                  <option>CPU-only Laptop</option>
                  <option>Single GPU</option>
                  <option>Multi-GPU Cluster</option>
                </select>
              </SettingRow>
              <SettingRow label="Arrow Spill Threshold (% RAM)" desc="When estimated memory demand exceeds this threshold, JEP switches to Arrow disk-spill streaming mode.">
                <input type="number" defaultValue={80} min={50} max={95}
                  className="w-20 bg-[#1E2D42] border border-[#2A3F5C] rounded px-2 py-1 text-xs text-[#E2EAF4] focus:outline-none text-center" />
              </SettingRow>
              <SettingRow label="Arrow IPC Batch Size (rows)">
                <input type="number" defaultValue={100000}
                  className="w-28 bg-[#1E2D42] border border-[#2A3F5C] rounded px-2 py-1 text-xs text-[#E2EAF4] focus:outline-none text-center" />
              </SettingRow>
            </Section>

            <Section title="Streaming Engine (JSR)">
              <SettingRow label="Checkpoint Recovery" desc="Streaming state snapshots enable exact recovery within 30s of pod restart.">
                <Toggle2 value={streamCheckpoint} onChange={setStreamCheckpoint} />
              </SettingRow>
              <SettingRow label="Checkpoint Interval">
                <select className="bg-[#1E2D42] border border-[#2A3F5C] rounded px-2 py-1 text-xs text-[#E2EAF4]">
                  <option>10 seconds</option>
                  <option>30 seconds</option>
                  <option>60 seconds</option>
                  <option>5 minutes</option>
                </select>
              </SettingRow>
              <SettingRow label="Default Window Type">
                <select className="bg-[#1E2D42] border border-[#2A3F5C] rounded px-2 py-1 text-xs text-[#E2EAF4]">
                  <option>Tumbling (1s)</option>
                  <option>Sliding (5s, step 1s)</option>
                  <option>Session (idle 30s)</option>
                  <option>Global</option>
                </select>
              </SettingRow>
            </Section>
          </>
        )}

        {active === "connections" && (
          <Section title="Database & Streaming Connections">
            <div className="space-y-3 py-3">
              {[
                { name: "PostgreSQL (Metadata Store)", status: "connected", host: "postgres.internal:5432" },
                { name: "Redis 7 (Execution Cache)", status: "connected", host: "redis-cluster.internal:6379" },
                { name: "Apache Kafka (KRaft)", status: "connected", host: "kafka-1:9092, kafka-2:9092, kafka-3:9092" },
                { name: "MinIO (Object Storage)", status: "connected", host: "minio.internal:9000" },
                { name: "Meilisearch (Node Index)", status: "connected", host: "meilisearch.internal:7700" },
                { name: "Keycloak (Auth)", status: "connected", host: "auth.internal:8443" },
              ].map((conn) => (
                <div key={conn.name} className="flex items-center gap-3 p-3 bg-[#1E2D42] rounded-lg border border-[#2A3F5C]">
                  <div className="w-2 h-2 rounded-full bg-[#10B981] shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-[#E2EAF4]">{conn.name}</p>
                    <p className="text-[10px] text-[#4B6080] font-mono truncate">{conn.host}</p>
                  </div>
                  <span className="text-[10px] text-[#10B981] shrink-0">Connected</span>
                </div>
              ))}
            </div>
          </Section>
        )}

        {active === "users" && (
          <Section title="RBAC Roles & Permissions">
            <div className="overflow-x-auto py-3">
              <table className="w-full text-xs border-collapse">
                <thead>
                  <tr className="border-b border-[#1E2D42]">
                    {["Role", "Workflow", "Dashboard", "GPU Pool", "Extensions", "Admin"].map((h) => (
                      <th key={h} className="text-left py-2 px-3 text-[10px] text-[#4B6080]">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[
                    { role: "System Admin", color: "#EF4444", wf: "R/W/E/D", dash: "R/W/Share", gpu: "Use/Manage", ext: "Publish/Manage", admin: "Full" },
                    { role: "Workspace Owner", color: "#F97316", wf: "R/W/E/D", dash: "R/W/Share", gpu: "Use", ext: "Publish", admin: "Workspace" },
                    { role: "Data Scientist", color: "#8B5CF6", wf: "R/W/Execute", dash: "R/W", gpu: "Use", ext: "Install", admin: "—" },
                    { role: "Data Engineer", color: "#3B82F6", wf: "R/W/Execute", dash: "Read", gpu: "Use", ext: "Install", admin: "—" },
                    { role: "BI Viewer", color: "#10B981", wf: "Read", dash: "Read", gpu: "—", ext: "—", admin: "—" },
                    { role: "Extension Publisher", color: "#F59E0B", wf: "Read", dash: "Read", gpu: "—", ext: "Publish", admin: "—" },
                  ].map((row) => (
                    <tr key={row.role} className="border-b border-[#1E2D42]/50 hover:bg-[#1E2D42]/30 transition-colors">
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px]" style={{ background: row.color + "20", color: row.color }}>
                          {row.role}
                        </span>
                      </td>
                      {[row.wf, row.dash, row.gpu, row.ext, row.admin].map((v, i) => (
                        <td key={i} className="py-2.5 px-3 text-[10px] text-[#6B8AAE]">{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Section>
        )}

        {active === "platform" && (
          <Section title="Platform Information">
            <div className="py-3 grid grid-cols-2 gap-x-8 gap-y-3">
              {[
                ["JuliaFlow Version", "1.0.2"],
                ["Julia Runtime", "1.10.4 LTS (JIT via LLVM 16)"],
                ["Platform Edition", "JuliaFlow Enterprise"],
                ["Deployment Mode", "Kubernetes 1.29 (Helm)"],
                ["CPU Workers", "4 × 16-32 core"],
                ["GPU Workers", "4 (2× A100 + 2× RTX4090)"],
                ["Total VRAM", "208 GB"],
                ["Arrow IPC Bus", "Redis Stream + MinIO"],
                ["Authentication", "Keycloak 24 (OIDC/SAML)"],
                ["License", "Enterprise (BSL 1.1)"],
                ["Uptime SLA", "99.9% monthly"],
                ["Build", "2026-04-21 · commit a3f7b92"],
              ].map(([k, v]) => (
                <div key={k} className="flex gap-2">
                  <span className="text-[10px] text-[#4B6080] w-36 shrink-0">{k}</span>
                  <span className="text-[10px] text-[#E2EAF4] font-mono">{v}</span>
                </div>
              ))}
            </div>
          </Section>
        )}

        {active === "notifications" && (
          <Section title="Notification Settings">
            {[
              { label: "Workflow Execution Complete", desc: "Notify when a batch workflow finishes successfully." },
              { label: "Workflow Error", desc: "Alert on node execution failure." },
              { label: "Streaming Pipeline Lag", desc: "Alert when Kafka consumer lag exceeds threshold." },
              { label: "GPU OOM Warning", desc: "Alert when GPU VRAM usage exceeds 90%." },
              { label: "Extension Update Available", desc: "Notify when installed extensions have updates on Hub." },
              { label: "Security Event", desc: "Alert on failed authentication attempts." },
            ].map((n) => (
              <SettingRow key={n.label} label={n.label} desc={n.desc}>
                <Toggle2 value={true} onChange={() => {}} />
              </SettingRow>
            ))}
          </Section>
        )}
      </div>
    </div>
  );
}
